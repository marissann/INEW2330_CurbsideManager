﻿
namespace SMB3_Curbside_Manager
{
    partial class frmAdmin_Merchandise_View
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblProductIDText = new System.Windows.Forms.Label();
            this.lblCategoryIDText = new System.Windows.Forms.Label();
            this.lblQuantityText = new System.Windows.Forms.Label();
            this.lblProductNametxt = new System.Windows.Forms.Label();
            this.lblInStockText = new System.Windows.Forms.Label();
            this.lblPriceText = new System.Windows.Forms.Label();
            this.btnLast = new System.Windows.Forms.Button();
            this.btnPrevious = new System.Windows.Forms.Button();
            this.btnNext = new System.Windows.Forms.Button();
            this.btnFirst = new System.Windows.Forms.Button();
            this.tbxPrice = new System.Windows.Forms.TextBox();
            this.tbxQuantity = new System.Windows.Forms.TextBox();
            this.tbxProductName = new System.Windows.Forms.TextBox();
            this.tbxCategoryID = new System.Windows.Forms.TextBox();
            this.tbxProductID = new System.Windows.Forms.TextBox();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnAddNew = new System.Windows.Forms.Button();
            this.btnEdit = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.tbxInStock = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblProductIDText
            // 
            this.lblProductIDText.AutoSize = true;
            this.lblProductIDText.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProductIDText.Location = new System.Drawing.Point(23, 31);
            this.lblProductIDText.Name = "lblProductIDText";
            this.lblProductIDText.Size = new System.Drawing.Size(76, 16);
            this.lblProductIDText.TabIndex = 16;
            this.lblProductIDText.Text = "Product ID :";
            this.lblProductIDText.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblCategoryIDText
            // 
            this.lblCategoryIDText.AutoSize = true;
            this.lblCategoryIDText.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCategoryIDText.Location = new System.Drawing.Point(23, 74);
            this.lblCategoryIDText.Name = "lblCategoryIDText";
            this.lblCategoryIDText.Size = new System.Drawing.Size(85, 16);
            this.lblCategoryIDText.TabIndex = 17;
            this.lblCategoryIDText.Text = "Catagory ID :";
            this.lblCategoryIDText.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblQuantityText
            // 
            this.lblQuantityText.AutoSize = true;
            this.lblQuantityText.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuantityText.Location = new System.Drawing.Point(23, 171);
            this.lblQuantityText.Name = "lblQuantityText";
            this.lblQuantityText.Size = new System.Drawing.Size(65, 16);
            this.lblQuantityText.TabIndex = 18;
            this.lblQuantityText.Text = "Quantity : ";
            this.lblQuantityText.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblProductNametxt
            // 
            this.lblProductNametxt.AutoSize = true;
            this.lblProductNametxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProductNametxt.Location = new System.Drawing.Point(23, 118);
            this.lblProductNametxt.Name = "lblProductNametxt";
            this.lblProductNametxt.Size = new System.Drawing.Size(103, 16);
            this.lblProductNametxt.TabIndex = 19;
            this.lblProductNametxt.Text = "Product Name : ";
            this.lblProductNametxt.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblInStockText
            // 
            this.lblInStockText.AutoSize = true;
            this.lblInStockText.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInStockText.Location = new System.Drawing.Point(23, 275);
            this.lblInStockText.Name = "lblInStockText";
            this.lblInStockText.Size = new System.Drawing.Size(64, 16);
            this.lblInStockText.TabIndex = 20;
            this.lblInStockText.Text = "In Stock : ";
            this.lblInStockText.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblPriceText
            // 
            this.lblPriceText.AutoSize = true;
            this.lblPriceText.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPriceText.Location = new System.Drawing.Point(23, 223);
            this.lblPriceText.Name = "lblPriceText";
            this.lblPriceText.Size = new System.Drawing.Size(48, 16);
            this.lblPriceText.TabIndex = 21;
            this.lblPriceText.Text = "Price : ";
            this.lblPriceText.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnLast
            // 
            this.btnLast.Location = new System.Drawing.Point(313, 315);
            this.btnLast.Name = "btnLast";
            this.btnLast.Size = new System.Drawing.Size(75, 23);
            this.btnLast.TabIndex = 31;
            this.btnLast.Text = "Last";
            this.btnLast.UseVisualStyleBackColor = true;
            this.btnLast.Click += new System.EventHandler(this.btnLast_Click);
            // 
            // btnPrevious
            // 
            this.btnPrevious.Location = new System.Drawing.Point(24, 315);
            this.btnPrevious.Name = "btnPrevious";
            this.btnPrevious.Size = new System.Drawing.Size(75, 23);
            this.btnPrevious.TabIndex = 28;
            this.btnPrevious.Text = "Previous";
            this.btnPrevious.UseVisualStyleBackColor = true;
            this.btnPrevious.Click += new System.EventHandler(this.btnPrevious_Click);
            // 
            // btnNext
            // 
            this.btnNext.Location = new System.Drawing.Point(117, 315);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(75, 23);
            this.btnNext.TabIndex = 29;
            this.btnNext.Text = "Next";
            this.btnNext.UseVisualStyleBackColor = true;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // btnFirst
            // 
            this.btnFirst.Location = new System.Drawing.Point(221, 315);
            this.btnFirst.Name = "btnFirst";
            this.btnFirst.Size = new System.Drawing.Size(75, 23);
            this.btnFirst.TabIndex = 30;
            this.btnFirst.Text = "First";
            this.btnFirst.UseVisualStyleBackColor = true;
            this.btnFirst.Click += new System.EventHandler(this.btnFirst_Click);
            // 
            // tbxPrice
            // 
            this.tbxPrice.Location = new System.Drawing.Point(140, 223);
            this.tbxPrice.Name = "tbxPrice";
            this.tbxPrice.Size = new System.Drawing.Size(246, 20);
            this.tbxPrice.TabIndex = 60;
            // 
            // tbxQuantity
            // 
            this.tbxQuantity.Location = new System.Drawing.Point(140, 171);
            this.tbxQuantity.Name = "tbxQuantity";
            this.tbxQuantity.Size = new System.Drawing.Size(246, 20);
            this.tbxQuantity.TabIndex = 59;
            // 
            // tbxProductName
            // 
            this.tbxProductName.Location = new System.Drawing.Point(140, 118);
            this.tbxProductName.Name = "tbxProductName";
            this.tbxProductName.Size = new System.Drawing.Size(246, 20);
            this.tbxProductName.TabIndex = 58;
            // 
            // tbxCategoryID
            // 
            this.tbxCategoryID.Location = new System.Drawing.Point(140, 74);
            this.tbxCategoryID.Name = "tbxCategoryID";
            this.tbxCategoryID.Size = new System.Drawing.Size(246, 20);
            this.tbxCategoryID.TabIndex = 57;
            // 
            // tbxProductID
            // 
            this.tbxProductID.Location = new System.Drawing.Point(140, 28);
            this.tbxProductID.Name = "tbxProductID";
            this.tbxProductID.Size = new System.Drawing.Size(246, 20);
            this.tbxProductID.TabIndex = 56;
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(117, 374);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(75, 23);
            this.btnDelete.TabIndex = 61;
            this.btnDelete.Text = "&Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnAddNew
            // 
            this.btnAddNew.Location = new System.Drawing.Point(24, 345);
            this.btnAddNew.Name = "btnAddNew";
            this.btnAddNew.Size = new System.Drawing.Size(75, 23);
            this.btnAddNew.TabIndex = 62;
            this.btnAddNew.Text = "&Add New";
            this.btnAddNew.UseVisualStyleBackColor = true;
            this.btnAddNew.Click += new System.EventHandler(this.btnAddNew_Click);
            // 
            // btnEdit
            // 
            this.btnEdit.Location = new System.Drawing.Point(117, 345);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(75, 23);
            this.btnEdit.TabIndex = 63;
            this.btnEdit.Text = "&Edit";
            this.btnEdit.UseVisualStyleBackColor = true;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(221, 345);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 64;
            this.btnSave.Text = "&Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(313, 345);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 65;
            this.btnCancel.Text = "&Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(221, 374);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 85;
            this.btnClose.Text = "C&lose";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // tbxInStock
            // 
            this.tbxInStock.Location = new System.Drawing.Point(141, 275);
            this.tbxInStock.Name = "tbxInStock";
            this.tbxInStock.Size = new System.Drawing.Size(246, 20);
            this.tbxInStock.TabIndex = 86;
            // 
            // frmAdmin_Merchandise_View
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(415, 416);
            this.Controls.Add(this.tbxInStock);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnEdit);
            this.Controls.Add(this.btnAddNew);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.tbxPrice);
            this.Controls.Add(this.tbxQuantity);
            this.Controls.Add(this.tbxProductName);
            this.Controls.Add(this.tbxCategoryID);
            this.Controls.Add(this.tbxProductID);
            this.Controls.Add(this.btnLast);
            this.Controls.Add(this.btnFirst);
            this.Controls.Add(this.btnNext);
            this.Controls.Add(this.btnPrevious);
            this.Controls.Add(this.lblPriceText);
            this.Controls.Add(this.lblInStockText);
            this.Controls.Add(this.lblProductNametxt);
            this.Controls.Add(this.lblQuantityText);
            this.Controls.Add(this.lblCategoryIDText);
            this.Controls.Add(this.lblProductIDText);
            this.Name = "frmAdmin_Merchandise_View";
            this.Text = "frmMerchandiseInfo";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMerchandiseInfo_FormClosing);
            this.Load += new System.EventHandler(this.frmMerchandiseInfo_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblProductIDText;
        private System.Windows.Forms.Label lblCategoryIDText;
        private System.Windows.Forms.Label lblQuantityText;
        private System.Windows.Forms.Label lblProductNametxt;
        private System.Windows.Forms.Label lblInStockText;
        private System.Windows.Forms.Label lblPriceText;
        private System.Windows.Forms.Button btnLast;
        private System.Windows.Forms.Button btnPrevious;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.Button btnFirst;
        private System.Windows.Forms.TextBox tbxPrice;
        private System.Windows.Forms.TextBox tbxQuantity;
        private System.Windows.Forms.TextBox tbxProductName;
        private System.Windows.Forms.TextBox tbxCategoryID;
        private System.Windows.Forms.TextBox tbxProductID;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnAddNew;
        private System.Windows.Forms.Button btnEdit;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.TextBox tbxInStock;
    }
}