﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SMB3_Curbside_Manager
{
    public partial class frmEmployee_MerchandiseInfo : Form
    {
        public frmEmployee_MerchandiseInfo()
        {
            InitializeComponent();
        }
    }
}
