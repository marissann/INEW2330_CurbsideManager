﻿
namespace SMB3_Curbside_Manager
{
    partial class frmReports
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mnuMain = new System.Windows.Forms.MenuStrip();
            this.mnuMainItemFile = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuMainItmView = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuMainItmOrderNum = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuMainItmPrint = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuMainItemExit = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // mnuMain
            // 
            this.mnuMain.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.mnuMain.ImageScalingSize = new System.Drawing.Size(28, 28);
            this.mnuMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuMainItemFile});
            this.mnuMain.Location = new System.Drawing.Point(0, 0);
            this.mnuMain.Name = "mnuMain";
            this.mnuMain.Size = new System.Drawing.Size(765, 42);
            this.mnuMain.TabIndex = 1;
            this.mnuMain.Text = "menuStrip1";
            // 
            // mnuMainItemFile
            // 
            this.mnuMainItemFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuMainItmView,
            this.mnuMainItmPrint,
            this.mnuMainItemExit});
            this.mnuMainItemFile.Name = "mnuMainItemFile";
            this.mnuMainItemFile.Size = new System.Drawing.Size(62, 34);
            this.mnuMainItemFile.Text = "File";
            // 
            // mnuMainItmView
            // 
            this.mnuMainItmView.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuMainItmOrderNum});
            this.mnuMainItmView.Name = "mnuMainItmView";
            this.mnuMainItmView.Size = new System.Drawing.Size(315, 40);
            this.mnuMainItmView.Text = "&View";
            // 
            // mnuMainItmOrderNum
            // 
            this.mnuMainItmOrderNum.Name = "mnuMainItmOrderNum";
            this.mnuMainItmOrderNum.Size = new System.Drawing.Size(315, 40);
            this.mnuMainItmOrderNum.Text = "By &Order #";
            this.mnuMainItmOrderNum.Click += new System.EventHandler(this.mnuMainItmOrderNum_Click);
            // 
            // mnuMainItmPrint
            // 
            this.mnuMainItmPrint.Name = "mnuMainItmPrint";
            this.mnuMainItmPrint.Size = new System.Drawing.Size(315, 40);
            this.mnuMainItmPrint.Text = "&Print";
            this.mnuMainItmPrint.Click += new System.EventHandler(this.mnuMainItmPrint_Click);
            // 
            // mnuMainItemExit
            // 
            this.mnuMainItemExit.Name = "mnuMainItemExit";
            this.mnuMainItemExit.Size = new System.Drawing.Size(315, 40);
            this.mnuMainItemExit.Text = "E&xit";
            this.mnuMainItemExit.Click += new System.EventHandler(this.mnuMainItemExit_Click);
            // 
            // Reports
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(765, 741);
            this.ControlBox = false;
            this.Controls.Add(this.mnuMain);
            this.MainMenuStrip = this.mnuMain;
            this.Name = "Reports";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SMB Reports";
            this.mnuMain.ResumeLayout(false);
            this.mnuMain.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.MenuStrip mnuMain;
        private System.Windows.Forms.ToolStripMenuItem mnuMainItemFile;
        private System.Windows.Forms.ToolStripMenuItem mnuMainItmView;
        private System.Windows.Forms.ToolStripMenuItem mnuMainItmOrderNum;
        private System.Windows.Forms.ToolStripMenuItem mnuMainItmPrint;
        private System.Windows.Forms.ToolStripMenuItem mnuMainItemExit;
    }
}