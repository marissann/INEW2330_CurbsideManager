﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SMB3_Curbside_Manager
{
    public partial class frmMerchandiseInfo : Form
    {
        public frmMerchandiseInfo()
        {
            InitializeComponent();
        }

        //Set up merchandise CurrencyManager
        CurrencyManager merchManager;

        //Future variables for state and bookmark
        string myState = "";
        int myBookmark = 0;

        private void cbxInStock_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void frmMerchandiseInfo_Load(object sender, EventArgs e)
        {
            //Load in the Products table from the database
            ProgOps.FetchMerchandise(tbxProductID, tbxCategoryID, tbxProductName, tbxQuantity, tbxPrice, cbxInStock);

            //Fill the currency manager
            merchManager = (CurrencyManager)this.BindingContext[ProgOps.GetMerchandiseTable];
        }

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            //Move back one entry if currency manager is not at the first
            if (merchManager.Position != 0)
                merchManager.Position--;
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            //Move forward one entry if currency manager is not at the last

            if (merchManager.Position != merchManager.Count - 1)
            merchManager.Position++;
        }

        private void btnFirst_Click(object sender, EventArgs e)
        {
            //Move to the first entry
            merchManager.Position = 0;
        }

        private void btnLast_Click(object sender, EventArgs e)
        {
            //Move to the last entry
            merchManager.Position = merchManager.Count - 1;
        }


        //for btnDelete

        // try
        //  {
        // DialogResult response;
        // response = MessageBox.Show("Are you sure you want to delete this item?", "Delete", MessageBoxButtons.OK,MessageBoxButtons.YesNo, MessageBoxIcon.Question,MessageBoxDefaultButton.Button2);
        // 
        // if (response == DialogRsult.No)
        //   {
        //     return;
        //   }
        // 

        // catch (Exception ex)
        //      {
        //    MessageBox.Show("Error deleting record.", "Error", MessageBoxButtons.OK, MessageBoxButtonIcon.Error);
        //
        //     }
        
    }
}
