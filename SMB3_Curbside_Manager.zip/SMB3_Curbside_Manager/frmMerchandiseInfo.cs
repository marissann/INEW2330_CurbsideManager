﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SMB3_Curbside_Manager
{
    public partial class frmMerchandiseInfo : Form
    {
        public frmMerchandiseInfo()
        {
            InitializeComponent();
        }

        private void cbxInStock_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void frmMerchandiseInfo_Load(object sender, EventArgs e)
        {
            ProgOps.FetchMerchandise(tbxProductID, tbxCategoryID, tbxProductName, tbxPrice, tbxQuantity, cbxInStock);
        }
    }
}
