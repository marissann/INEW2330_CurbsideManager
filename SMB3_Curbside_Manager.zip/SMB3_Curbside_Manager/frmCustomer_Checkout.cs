﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SMB3_Curbside_Manager
{
    public partial class frmCustomer_Checkout : Form
    {
        public frmCustomer_Checkout()
        {
            InitializeComponent();
        }

        private void frmCustomer_Checkout_Load(object sender, EventArgs e)
        {
            lblTotal.Text = ProgOps.dblTotal.ToString("c2");
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
