﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SMB3_Curbside_Manager
{
    public partial class frmAdmin_Merchandise_View : Form
    {
        public frmAdmin_Merchandise_View()
        {
            InitializeComponent();
        }

        //Set up merchandise CurrencyManager
        CurrencyManager merchManager;

        //Future variables for state and bookmark
        string myState = "";
        int myBookmark = 0;

        private void frmMerchandiseInfo_Load(object sender, EventArgs e)
        {
            try
            {
                //Load in the Products table from the database
                ProgOps.FetchMerchandise(tbxProductID, tbxCategoryID, tbxProductName, tbxQuantity, tbxPrice, tbxInStock);

                //Fill the currency manager
                merchManager = (CurrencyManager)this.BindingContext[ProgOps.GetMerchandiseTable];

                //Start in view state
                SetState("View");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error : Products Table ", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            //Move back one entry if currency manager is not at the first
            if (merchManager.Position != 0)
                merchManager.Position--;
        }
        private void btnNext_Click(object sender, EventArgs e)
        {
            //Move forward one entry if currency manager is not at the last
            if (merchManager.Position != merchManager.Count - 1)
                merchManager.Position++;
        }
        private void btnFirst_Click(object sender, EventArgs e)
        {
            //Move to the first entry
            merchManager.Position = 0;
        }
        private void btnLast_Click(object sender, EventArgs e)
        {
            //Move to the last entry
            merchManager.Position = merchManager.Count - 1;
        }
        private void btnAddNew_Click(object sender, EventArgs e)
        {
            try 
            {
                myBookmark = merchManager.Position;
                merchManager.AddNew();
                SetState("Add");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error : In Add New ", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }
        private void btnEdit_Click(object sender, EventArgs e)
        {
            //Set the form into "Edit" mode
            SetState("Edit");
        }
        private void btnSave_Click(object sender, EventArgs e)
        {
            //Trim the textbox(s) that don't reject spaces
            tbxProductName.Text = tbxProductName.Text.Trim();

            if (DataIsValid(tbxCategoryID.Text, tbxProductName.Text, tbxQuantity.Text, tbxPrice.Text, tbxInStock.Text))
            {
                //variables to hold save data
                string savedName = tbxProductName.Text;
                int savedRow;

                //Have the currency manager end the edit and re-sort the table
                merchManager.EndCurrentEdit();
                ProgOps.GetMerchandiseTable.DefaultView.Sort = "ProductName";

                savedRow = ProgOps.GetMerchandiseTable.DefaultView.Find(savedName);

                merchManager.Position = savedRow;

                //Return to view state
                SetState("View");

                //Display confirming message box
                MessageBox.Show("Record saved successfully.", "Save Record", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            //Cancel the edit
            merchManager.CancelCurrentEdit();

            //If cancelling from adding an entry, return to saved position
            if(myState == "Add")
                merchManager.Position = myBookmark;

            //Return to view mode
            SetState("View");
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            //Close the form
            this.Close();
        }

        private void SetState(string state)
        {
        myState = state;

            switch (state)
            {
            case "View":
                    //Buttons
                    btnPrevious.Enabled = true;
                    btnNext.Enabled = true;
                    btnLast.Enabled = true;
                    btnFirst.Enabled = true;
                    btnAddNew.Enabled = true;
                    btnEdit.Enabled = true;
                    btnSave.Enabled = false;
                    btnCancel.Enabled = false;
                    btnClose.Enabled = true;
                    //textbox
                    tbxProductID.BackColor = Color.White;
                    tbxCategoryID.ReadOnly = true;
                    tbxProductName.ReadOnly = true;
                    tbxQuantity.ReadOnly = true;
                    tbxPrice.ReadOnly = true;
                    tbxInStock.ReadOnly = true;
                break;
            default:
                    //Buttons
                    btnPrevious.Enabled = false;
                    btnNext.Enabled = false;
                    btnLast.Enabled = false;
                    btnFirst.Enabled = false;
                    btnAddNew.Enabled = false;
                    btnEdit.Enabled = false;
                    btnSave.Enabled = true;
                    btnCancel.Enabled = true;
                    btnClose.Enabled = false;
                    //textbox
                    tbxProductID.BackColor = Color.Red;
                    tbxCategoryID.ReadOnly = false;
                    tbxProductName.ReadOnly = false;
                    tbxQuantity.ReadOnly = false;
                    tbxPrice.ReadOnly = false;
                    tbxInStock.ReadOnly = false;
                break;
            }
        }

        private void frmMerchandiseInfo_FormClosing(object sender, FormClosingEventArgs e)
        {
            //Check if the user is not in view mode
            if(myState != "View")
            {
                //Display notification and cancel close
                MessageBox.Show("You must finish the current edit before closing the application.", "Finish Edit",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                e.Cancel = true;
            }
            else
            {
                //Update database
                ProgOps.UpdateMerchOnClose();
                ProgOps.DisposeMerchObjects();
            }
        }

        private void tbxCategoryID_KeyPress(object sender, KeyPressEventArgs e)
        {
            //Only allow numbers and backspace
            if(e.KeyChar >= 48 && e.KeyChar <= 57 ||        //ASCII Check for Numbers
               e.KeyChar == 8)                              //ASCII Check for Backspace
            {
                //Allow the key press
                e.Handled = false;
            }
            else
            {
                //Deny the key press
                e.Handled = true;
            }
        }

        private void tbxProductName_KeyPress(object sender, KeyPressEventArgs e)
        {
            //Likely doesn't need any kind of validation
        }

        private void tbxQuantity_KeyPress(object sender, KeyPressEventArgs e)
        {
            //Only allow numbers and backspace
            if (e.KeyChar >= 48 && e.KeyChar <= 57 ||        //ASCII Check for Numbers
                e.KeyChar == 8)                              //ASCII Check for Backspace
            {
                //Allow the key press
                e.Handled = false;
            }
            else
            {
                //Deny the key press
                e.Handled = true;
            }
        }

        private void tbxPrice_KeyPress(object sender, KeyPressEventArgs e)
        {
            //Only allow numbers, dots and backspace
            if (e.KeyChar >= 48 && e.KeyChar <= 57 ||        //ASCII Check for Numbers
                e.KeyChar == 46 ||                           //ASCII Check for Dots (Decimal point in this case)
                e.KeyChar == 8)                              //ASCII Check for Backspace
            {
                //Allow the key press
                e.Handled = false;
            }
            else
            {
                //Deny the key press
                e.Handled = true;
            }
        }

        private void tbxInStock_KeyPress(object sender, KeyPressEventArgs e)
        {
            //Only allow letters and backspace
            if (e.KeyChar >= 65 && e.KeyChar <= 90 ||       //ASCII Check for Capital Letters
               e.KeyChar >= 97 && e.KeyChar <= 122 ||       //ASCII Check for Lowercase Letters
               e.KeyChar == 8)                              //ASCII Check for Backspace
            {
                //Accept the keystroke
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        public bool DataIsValid(string categoryID, string productName, string quantity,
                                string price, string inStock)
        {
            //Check if any textbox is empty
            if (categoryID == "" || productName == "" || quantity == "" || price == "" || inStock == "")
            {
                MessageBox.Show("Please make sure all fields are filled in.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            //Check if the entered CategoryID exists within the database
            if(!ProgOps.CategoryExists(int.Parse(categoryID)))
            {
                MessageBox.Show("The Category ID entered does not exist within the database. Please enter an existing Category ID.",
                                "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            return true;
        }
    }
}  


    
