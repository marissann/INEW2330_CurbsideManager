﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SMB3_Curbside_Manager
{
    public partial class frmReports : Form
    {
        public frmReports()
        {
            InitializeComponent();
        }

        //private void btnReports_Click(object sender, EventArgs e)
        //{
        //    //create an object of the report
        //    CrystalReports.crptOrder order = new CrystalReports.crptOrder();

        //    //set the db logon for the reports
        //    order.SetDatabaseLogon("group3sp212330", "3815294");

        //    //create an object of the frmViewer so we can use the crvViewer
        //    frmViewer viewer = new frmViewer();

        //    //set to null first to clear the crvViewer
        //    viewer.crvViewer.ReportSource = null;

        //    //then set crvViewer to report object
        //    viewer.crvViewer.ReportSource = order;

        //    //then show the form with the crvViewer on it
        //    viewer.Show();
        //}

        private void mnuMainItmOrderNum_Click(object sender, EventArgs e)
        {
            //create an object of the report
            CrystalReports.crptOrder order = new CrystalReports.crptOrder();

            //set the db logon for the reports
            order.SetDatabaseLogon("group3sp212330", "3815294");

            //create an object of the frmViewer so we can use the crvViewer
            frmViewer viewer = new frmViewer();

            //set to null first to clear the crvViewer
            viewer.crvViewer.ReportSource = null;

            //then set crvViewer to report object
            viewer.crvViewer.ReportSource = order;

            //then show the form with the crvViewer on it
            viewer.Show();
        }

        private void mnuMainItemExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void mnuMainItmPrint_Click(object sender, EventArgs e)
        {
            {
                //create an object of the report
                CrystalReports.crptOrder order = new CrystalReports.crptOrder();

                //set the db logon for the reports
                order.SetDatabaseLogon("group3sp212330", "3815294");

                //create an object of the frmViewer so we can use the crvViewer
                frmViewer viewer = new frmViewer();

                //set to null first to clear the crvViewer
                viewer.crvViewer.ReportSource = null;

                //then set crvViewer to report object
                viewer.crvViewer.ReportSource = order;

                //then show the form with the crvViewer on it
                viewer.Show();
            }
        }
    }
}
