﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;

namespace SMB3_Curbside_Manager
{
    public partial class frmCustomer_OrderCreate : Form
    {
        public frmCustomer_OrderCreate()
        {
            InitializeComponent();
        }

        double Total = 0.0;

        public struct Product
        {
            //struct variables
            public int productID;
            public string productName;
            public double productPrice;
            public int itemQuantity;

            //constructor
            public Product(int productID, string productName, double productPrice, int itemQuantity)
            {
                this.productID = productID;
                this.productName = productName;
                this.productPrice = productPrice;
                this.itemQuantity = itemQuantity;
            }
        }

        List<Product> productList = new List<Product>();


        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmCustomer_OrderCreate_Load(object sender, EventArgs e)
        {
            ProgOps.DisplayOrderGrid(tbxMerchandiseID, dgvMerchandise, true);
        }

        private void btnAddToOrder_Click(object sender, EventArgs e)
        {
            
            double dblPrice;
            if (tbxMerchandiseID.Text == "")
            {

                ProgOps.DisplayOrderGrid(tbxMerchandiseID, dgvMerchandise, true);
                lblError.Visible = false;
            }
            else if (tbxQuantity.Text == "" || tbxQuantity.Text == "0" && tbxMerchandiseID.Text != "")
            {
                //Display error label if neither text box is filled out
                lblError.Visible = true;
            }
            else
            {
                //Turn off error label
                lblError.Visible = false;
                Console.WriteLine(Total);

                //Try to grab an item from the list
                ProgOps.DisplayOrderGrid(tbxMerchandiseID, dgvMerchandise, false);

                //If a row is found, then add it to the cart
                if (dgvMerchandise.RowCount != 1)
                {
                    Console.WriteLine(dgvMerchandise.RowCount);
                    //Add order to cart on form
                    lbxOrder.Items.Add("Item Name : " + dgvMerchandise.CurrentRow.Cells[1].Value.ToString());
                    lbxOrder.Items.Add("Price: $" + dgvMerchandise.CurrentRow.Cells[2].Value);
                    lbxOrder.Items.Add("Quantity: " + tbxQuantity.Text);
                    dblPrice = Convert.ToDouble(dgvMerchandise.CurrentRow.Cells[2].Value);

                    //Update the total and its label
                    Total += dblPrice * double.Parse(tbxQuantity.Text);
                    lblToalPrice.Text = "Total : \t" + Total.ToString("c2");

                    //Add the selected item to the product list
                    productList.Add(new Product(int.Parse(tbxMerchandiseID.Text), dgvMerchandise.CurrentRow.Cells[1].Value.ToString(), dblPrice, int.Parse(tbxQuantity.Text)));
                }
                else
                {
                    MessageBox.Show("The entered Food ID doesn't exist within our inventory.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                //Display each item again
                ProgOps.DisplayOrderGrid(tbxMerchandiseID, dgvMerchandise, true);
            }
        }

        private void btnCheckOut_Click(object sender, EventArgs e)
        {
            if (Total != 0)
            {
                //Create the order
                ProgOps.CreateOrder(Total);
                ProgOps.dblTotal = Total;
                //Record each item into this order's information
                for (int i = 0; i < productList.Count; i++)
                {
                    ProgOps.FillOrderInfo(productList[i].productID, productList[i].itemQuantity, productList[i].productPrice);
                }
                frmCustomer_Checkout frmCheckOut = new frmCustomer_Checkout();
                frmCheckOut.ShowDialog();
                this.Close();
            }
            else
            {
                MessageBox.Show("There is nothing in your shopping cart.", "Empty Cart", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        private void tbxMerchandiseID_TextChanged(object sender, EventArgs e)
        {

        }

        private void tbxQuantity_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblOrderDetails_Click(object sender, EventArgs e)
        {

        }

        private void frmCustomer_OrderCreate_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void tbxMerchandiseID_KeyPress(object sender, KeyPressEventArgs e)
        {
            //Only allow numbers and backspace
            if (e.KeyChar >= 48 && e.KeyChar <= 57 ||       //ASCII Check for Numbers
               e.KeyChar == 8)                              //ASCII Check for Backspace
            {
                //Accept the keystroke
                e.Handled = false;
                lblFoodIDError.Visible = false;
            }
            else
            {
                //Deny the keystroke
                e.Handled = true;
                SystemSounds.Beep.Play();
                lblFoodIDError.Visible = true;
            }
        }

        private void tbxQuantity_KeyPress(object sender, KeyPressEventArgs e)
        {
            //Only allow numbers and backspace
            if (e.KeyChar >= 48 && e.KeyChar <= 57 ||       //ASCII Check for Numbers
               e.KeyChar == 8)                              //ASCII Check for Backspace
            {
                //Accept the keystroke
                e.Handled = false;
                lblError.Visible = false;
                lblError.Text = "*Required Field";
            }
            else
            {
                //Deny the keystroke
                e.Handled = true;
                SystemSounds.Beep.Play();
                lblError.Visible = true;
                lblError.Text = "Numbers Only";
            }
        }
    }
}
