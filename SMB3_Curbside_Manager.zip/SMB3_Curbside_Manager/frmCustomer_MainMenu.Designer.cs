﻿
namespace SMB3_Curbside_Manager
{
    partial class frmCustomer_MainMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnExit = new System.Windows.Forms.Button();
            this.lblUserId = new System.Windows.Forms.Label();
            this.lblWelcomeUserText = new System.Windows.Forms.Label();
            this.lblBlackLine = new System.Windows.Forms.Label();
            this.btnMerchandiseView = new System.Windows.Forms.Button();
            this.btnOrderCreate = new System.Windows.Forms.Button();
            this.lblDate = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnExit
            // 
            this.btnExit.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(287, 388);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(100, 41);
            this.btnExit.TabIndex = 19;
            this.btnExit.Text = "E&xit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // lblUserId
            // 
            this.lblUserId.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUserId.Location = new System.Drawing.Point(155, 6);
            this.lblUserId.Name = "lblUserId";
            this.lblUserId.Size = new System.Drawing.Size(100, 23);
            this.lblUserId.TabIndex = 18;
            this.lblUserId.Text = "Customer";
            this.lblUserId.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblWelcomeUserText
            // 
            this.lblWelcomeUserText.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWelcomeUserText.Location = new System.Drawing.Point(5, 6);
            this.lblWelcomeUserText.Name = "lblWelcomeUserText";
            this.lblWelcomeUserText.Size = new System.Drawing.Size(114, 23);
            this.lblWelcomeUserText.TabIndex = 17;
            this.lblWelcomeUserText.Text = "Welcome : ";
            // 
            // lblBlackLine
            // 
            this.lblBlackLine.BackColor = System.Drawing.Color.Black;
            this.lblBlackLine.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblBlackLine.Location = new System.Drawing.Point(1, 34);
            this.lblBlackLine.Name = "lblBlackLine";
            this.lblBlackLine.Size = new System.Drawing.Size(476, 3);
            this.lblBlackLine.TabIndex = 16;
            this.lblBlackLine.Text = "lblBlackLine";
            this.lblBlackLine.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // btnMerchandiseView
            // 
            this.btnMerchandiseView.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMerchandiseView.Location = new System.Drawing.Point(139, 232);
            this.btnMerchandiseView.Name = "btnMerchandiseView";
            this.btnMerchandiseView.Size = new System.Drawing.Size(130, 60);
            this.btnMerchandiseView.TabIndex = 15;
            this.btnMerchandiseView.Text = "&Merchandise Info";
            this.btnMerchandiseView.UseVisualStyleBackColor = true;
            this.btnMerchandiseView.Click += new System.EventHandler(this.btnMerchandiseView_Click);
            // 
            // btnOrderCreate
            // 
            this.btnOrderCreate.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOrderCreate.Location = new System.Drawing.Point(139, 153);
            this.btnOrderCreate.Name = "btnOrderCreate";
            this.btnOrderCreate.Size = new System.Drawing.Size(130, 60);
            this.btnOrderCreate.TabIndex = 14;
            this.btnOrderCreate.Text = "&Create New Order";
            this.btnOrderCreate.UseVisualStyleBackColor = true;
            this.btnOrderCreate.Click += new System.EventHandler(this.btnOrderCreate_Click);
            // 
            // lblDate
            // 
            this.lblDate.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDate.Location = new System.Drawing.Point(298, 6);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(100, 23);
            this.lblDate.TabIndex = 20;
            this.lblDate.Text = "Date";
            this.lblDate.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblDate.Click += new System.EventHandler(this.lblDate_Click);
            // 
            // frmCustomer_MainMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(399, 441);
            this.ControlBox = false;
            this.Controls.Add(this.lblDate);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.lblUserId);
            this.Controls.Add(this.lblWelcomeUserText);
            this.Controls.Add(this.lblBlackLine);
            this.Controls.Add(this.btnMerchandiseView);
            this.Controls.Add(this.btnOrderCreate);
            this.Name = "frmCustomer_MainMenu";
            this.Text = "Main Menu";
            this.Load += new System.EventHandler(this.frmCustomer_MainMenu_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label lblUserId;
        private System.Windows.Forms.Label lblWelcomeUserText;
        private System.Windows.Forms.Label lblBlackLine;
        private System.Windows.Forms.Button btnMerchandiseView;
        private System.Windows.Forms.Button btnOrderCreate;
        private System.Windows.Forms.Label lblDate;
    }
}