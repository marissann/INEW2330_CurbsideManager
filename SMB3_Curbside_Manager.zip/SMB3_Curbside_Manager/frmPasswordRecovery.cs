﻿using EmailValidation;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MailKit;
using MimeKit;
using MailKit.Net.Smtp;

namespace SMB3_Curbside_Manager
{
    public partial class frmPasswordRecovery : Form
    {
        public frmPasswordRecovery()
        {
            InitializeComponent();
        }
        private void frmPasswordRecovery_Load(object sender, EventArgs e)
        {
            //should anything happen here?
        }

        private void btnRecovery_Click(object sender, EventArgs e)
        {
            string email = tbxEmailRecovery.Text;


            //validate userInfo to see if it's in correct format
            if (tbxEmailRecovery.Text.Trim() == String.Empty || tbxEmailRecovery.Text.Length > 50 || !EmailValidator.Validate(tbxEmailRecovery.Text.Trim(), true, true))
            {
                lblEmailRecoveryError.Visible = true;
              //  btnRecovery.Visible = false;
                
            }
            else
            {
                lblEmailRecoveryError.Visible = false;
                btnRecovery.Visible = true;
            }



            //send email with matching password from the database to email address in textbox

            var message = new MimeMessage();
            message.From.Add(new MailboxAddress("Test1", "Test1@123.com"));
            message.To.Add(new MailboxAddress("Test2", "Test2@123.com"));
            message.Subject = "Test";

            message.Body = new TextPart("plain")
            {
                Text = @"Hey, guess what the magic word is?"
            };

            SmtpClient client = new SmtpClient();
            client.Connect("smtp_address_here", port_here, true);
            client.Authenticate("user_name_here", "pwd_here");

            client.Send(message);
            client.Disconnect(true);
            client.Dispose();
        }

        private void tbxEmailRecovery_TextChanged(object sender, EventArgs e)
        {
            //may need this later but i changed my mind on what i was going to put here
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            //returns user to login screen (closes this one)
            this.Close();
           
        }
    }
}
