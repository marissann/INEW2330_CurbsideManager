﻿
namespace SMB3_Curbside_Manager
{
    partial class frmCustomer_OrderCreate
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbxMerchandiseID = new System.Windows.Forms.TextBox();
            this.lbxOrder = new System.Windows.Forms.ListBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.lbltextID = new System.Windows.Forms.Label();
            this.lblcategoryText = new System.Windows.Forms.Label();
            this.btnAddToOrder = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.dgvMerchandise = new System.Windows.Forms.DataGridView();
            this.btnCheckOut = new System.Windows.Forms.Button();
            this.lblAmount = new System.Windows.Forms.Label();
            this.tbxQuantity = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMerchandise)).BeginInit();
            this.SuspendLayout();
            // 
            // tbxMerchandiseID
            // 
            this.tbxMerchandiseID.Location = new System.Drawing.Point(111, 31);
            this.tbxMerchandiseID.Name = "tbxMerchandiseID";
            this.tbxMerchandiseID.Size = new System.Drawing.Size(132, 20);
            this.tbxMerchandiseID.TabIndex = 0;
            this.tbxMerchandiseID.TextChanged += new System.EventHandler(this.tbxMerchandiseID_TextChanged);
            // 
            // lbxOrder
            // 
            this.lbxOrder.FormattingEnabled = true;
            this.lbxOrder.Items.AddRange(new object[] {
            "Shopping Cart : "});
            this.lbxOrder.Location = new System.Drawing.Point(703, 34);
            this.lbxOrder.Name = "lbxOrder";
            this.lbxOrder.Size = new System.Drawing.Size(341, 368);
            this.lbxOrder.TabIndex = 1;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(111, 152);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(132, 20);
            this.textBox2.TabIndex = 2;
            // 
            // lbltextID
            // 
            this.lbltextID.AutoSize = true;
            this.lbltextID.Location = new System.Drawing.Point(36, 34);
            this.lbltextID.Name = "lbltextID";
            this.lbltextID.Size = new System.Drawing.Size(51, 13);
            this.lbltextID.TabIndex = 3;
            this.lbltextID.Text = "Food ID :";
            // 
            // lblcategoryText
            // 
            this.lblcategoryText.AutoSize = true;
            this.lblcategoryText.Location = new System.Drawing.Point(33, 152);
            this.lblcategoryText.Name = "lblcategoryText";
            this.lblcategoryText.Size = new System.Drawing.Size(69, 13);
            this.lblcategoryText.TabIndex = 4;
            this.lblcategoryText.Text = "CategoryID : ";
            // 
            // btnAddToOrder
            // 
            this.btnAddToOrder.Location = new System.Drawing.Point(12, 402);
            this.btnAddToOrder.Name = "btnAddToOrder";
            this.btnAddToOrder.Size = new System.Drawing.Size(90, 36);
            this.btnAddToOrder.TabIndex = 5;
            this.btnAddToOrder.Text = "Add";
            this.btnAddToOrder.UseVisualStyleBackColor = true;
            this.btnAddToOrder.Click += new System.EventHandler(this.btnAddToOrder_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(218, 402);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(91, 36);
            this.btnExit.TabIndex = 6;
            this.btnExit.Text = "E&xit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // dgvMerchandise
            // 
            this.dgvMerchandise.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvMerchandise.Location = new System.Drawing.Point(329, 31);
            this.dgvMerchandise.Name = "dgvMerchandise";
            this.dgvMerchandise.Size = new System.Drawing.Size(358, 370);
            this.dgvMerchandise.TabIndex = 7;
            // 
            // btnCheckOut
            // 
            this.btnCheckOut.Location = new System.Drawing.Point(111, 402);
            this.btnCheckOut.Name = "btnCheckOut";
            this.btnCheckOut.Size = new System.Drawing.Size(90, 36);
            this.btnCheckOut.TabIndex = 8;
            this.btnCheckOut.Text = "CheckOut";
            this.btnCheckOut.UseVisualStyleBackColor = true;
            this.btnCheckOut.Click += new System.EventHandler(this.btnCheckOut_Click);
            // 
            // lblAmount
            // 
            this.lblAmount.AutoSize = true;
            this.lblAmount.Location = new System.Drawing.Point(36, 91);
            this.lblAmount.Name = "lblAmount";
            this.lblAmount.Size = new System.Drawing.Size(52, 13);
            this.lblAmount.TabIndex = 9;
            this.lblAmount.Text = "Amount : ";
            // 
            // tbxQuantity
            // 
            this.tbxQuantity.Location = new System.Drawing.Point(111, 91);
            this.tbxQuantity.Name = "tbxQuantity";
            this.tbxQuantity.Size = new System.Drawing.Size(132, 20);
            this.tbxQuantity.TabIndex = 10;
            // 
            // frmCustomer_OrderCreate
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1115, 450);
            this.ControlBox = false;
            this.Controls.Add(this.tbxQuantity);
            this.Controls.Add(this.lblAmount);
            this.Controls.Add(this.btnCheckOut);
            this.Controls.Add(this.dgvMerchandise);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnAddToOrder);
            this.Controls.Add(this.lblcategoryText);
            this.Controls.Add(this.lbltextID);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.lbxOrder);
            this.Controls.Add(this.tbxMerchandiseID);
            this.Name = "frmCustomer_OrderCreate";
            this.Text = "frmCustomer_OrderCreate";
            this.Load += new System.EventHandler(this.frmCustomer_OrderCreate_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvMerchandise)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbxMerchandiseID;
        private System.Windows.Forms.ListBox lbxOrder;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label lbltextID;
        private System.Windows.Forms.Label lblcategoryText;
        private System.Windows.Forms.Button btnAddToOrder;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.DataGridView dgvMerchandise;
        private System.Windows.Forms.Button btnCheckOut;
        private System.Windows.Forms.Label lblAmount;
        private System.Windows.Forms.TextBox tbxQuantity;
    }
}