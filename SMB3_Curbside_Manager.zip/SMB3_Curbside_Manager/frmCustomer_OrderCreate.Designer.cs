﻿
namespace SMB3_Curbside_Manager
{
    partial class frmCustomer_OrderCreate
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.lbxOrder = new System.Windows.Forms.ListBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.lbltextID = new System.Windows.Forms.Label();
            this.lblcategoryText = new System.Windows.Forms.Label();
            this.btnAddToOrder = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(111, 28);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(132, 20);
            this.textBox1.TabIndex = 0;
            // 
            // lbxOrder
            // 
            this.lbxOrder.FormattingEnabled = true;
            this.lbxOrder.Location = new System.Drawing.Point(417, 12);
            this.lbxOrder.Name = "lbxOrder";
            this.lbxOrder.Size = new System.Drawing.Size(371, 420);
            this.lbxOrder.TabIndex = 1;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(111, 77);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(132, 20);
            this.textBox2.TabIndex = 2;
            // 
            // lbltextID
            // 
            this.lbltextID.AutoSize = true;
            this.lbltextID.Location = new System.Drawing.Point(30, 31);
            this.lbltextID.Name = "lbltextID";
            this.lbltextID.Size = new System.Drawing.Size(51, 13);
            this.lbltextID.TabIndex = 3;
            this.lbltextID.Text = "Food ID :";
            // 
            // lblcategoryText
            // 
            this.lblcategoryText.AutoSize = true;
            this.lblcategoryText.Location = new System.Drawing.Point(12, 84);
            this.lblcategoryText.Name = "lblcategoryText";
            this.lblcategoryText.Size = new System.Drawing.Size(69, 13);
            this.lblcategoryText.TabIndex = 4;
            this.lblcategoryText.Text = "CategoryID : ";
            // 
            // btnAddToOrder
            // 
            this.btnAddToOrder.Location = new System.Drawing.Point(15, 380);
            this.btnAddToOrder.Name = "btnAddToOrder";
            this.btnAddToOrder.Size = new System.Drawing.Size(126, 52);
            this.btnAddToOrder.TabIndex = 5;
            this.btnAddToOrder.Text = "Add";
            this.btnAddToOrder.UseVisualStyleBackColor = true;
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(273, 380);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(105, 52);
            this.btnExit.TabIndex = 6;
            this.btnExit.Text = "E&xit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // frmCustomer_OrderCreate
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.ControlBox = false;
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnAddToOrder);
            this.Controls.Add(this.lblcategoryText);
            this.Controls.Add(this.lbltextID);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.lbxOrder);
            this.Controls.Add(this.textBox1);
            this.Name = "frmCustomer_OrderCreate";
            this.Text = "frmCustomer_OrderCreate";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.ListBox lbxOrder;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label lbltextID;
        private System.Windows.Forms.Label lblcategoryText;
        private System.Windows.Forms.Button btnAddToOrder;
        private System.Windows.Forms.Button btnExit;
    }
}