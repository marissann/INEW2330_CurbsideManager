﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EmailValidation;

namespace SMB3_Curbside_Manager
{
    public partial class frmSignUp : Form
    {
        public frmSignUp()
        {
            InitializeComponent();
        }

        private void frmSignUp_Load(object sender, EventArgs e)
        {
            
        }

        private void btnSignUp_Click(object sender, EventArgs e)
        {
            
            //bool to confirm if all fields are correctly input
            bool allValid = true;
            StringBuilder sb = new StringBuilder();

            //Firstname = 20, Lastname = 20, Phone = 20, Email = 50, User = 20, Password = 20
            //Validation for First Name
            if (tbxFirstName.Text.Trim() == String.Empty)
            {
                sb.AppendLine("First name can not be empty.");

             //   MessageBox.Show("First Name is empty. Please fill out all fields before continuing.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                allValid = false;
            }

            if(tbxFirstName.Text.Trim().Length > 20)
            {
                sb.AppendLine("Please limit First Name to 20 characters. ");
               // MessageBox.Show("First Name exceeds character limit of 20.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                allValid = false;
            }

            //Validation for Last Name
            if (tbxLastName.Text.Trim() == String.Empty)
            {

                sb.AppendLine("Last name can not be empty.");
                // MessageBox.Show("Last Name is empty. Please fill out all fields before continuing.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                allValid = false;
            }

            if(tbxLastName.Text.Trim().Length > 20)
            {
                sb.AppendLine("Please limit Last Name to 20 characters. ");
                //  MessageBox.Show("Last name exceeds character limit of 20.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                allValid = false;
            }

            //Validation for Phone Number
            if (tbxPhone.Text.Trim() == String.Empty)
            {
                sb.AppendLine("Phone number can not be empty.");
                // MessageBox.Show("Phone number is empty. Please fill out all fields before continuing.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                allValid = false;
            }

            //Validation for Email
            if (tbxEmail.Text.Trim() == String.Empty)
            {
                sb.AppendLine("Email can not be empty.");
                // MessageBox.Show("Email is empty. Please fill out all fields before continuing.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                allValid = false;
            }

            if(tbxEmail.Text.Trim().Length > 50)
            {
                sb.AppendLine("Email address is limited to 50 characters.");

                //  MessageBox.Show("Email entered exceeds the character limit of 50.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                allValid = false;
            }

            if(!EmailValidator.Validate(tbxEmail.Text.Trim(), true, true))
            {
                sb.AppendLine("Please use a valid format. (Example: TimDuncan@sportsball.com.)");
             //   MessageBox.Show("Email address could not be found. Please make sure you entered a correct email address.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                allValid = false;
            }

            //Validation for Username
            if (tbxUsername.Text.Trim() == String.Empty)
            {
                sb.AppendLine("Username may not be empty.");
                //   MessageBox.Show("Username is empty. Please fill out all fields before continuing.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                allValid = false;
            }

            if(tbxUsername.Text.Trim().Length > 20)
            {
                sb.AppendLine("Username is limited to 20 characters.");
                // MessageBox.Show("Username exceeds character limit of 20.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                allValid = false;
            }

            //Validation for Password
            if (tbxPassword.Text.Trim() == String.Empty)
            {
                sb.AppendLine("Password may not be empty.");
                // MessageBox.Show("Password is empty. Please fill out all fields before continuing.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                allValid = false;
            }

            if(tbxPassword.Text.Trim().Length > 20)
            {
                sb.AppendLine("Password is limited to 20 characters.");
                //  MessageBox.Show("Username exceeds character limit of 20.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                allValid = false;
            }

            if (tbxPassword.Text.Trim().Length < 8)
            {
                sb.AppendLine("Password must be at least eight characters.");
             //   MessageBox.Show("Password is too short.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                allValid = false;
            }

            //bool to tell if password has a number
            bool hasNumber = false;

            for (int i = 0; i < tbxPassword.Text.Trim().Length; i++)
            {
                if (tbxPassword.Text.Trim()[i] >= 48 && tbxPassword.Text.Trim()[i] <= 57)
                {
                    hasNumber = true;
                    break;
                }
            }

            if (!hasNumber)
                allValid = false;


            //int to track the number of symbols found in password
            int symbolCtr = 0;

            for (int i = 0; i < tbxPassword.Text.Trim().Length; i++)
            {

            }

            //If the entered data is all valid, attempt account creation
            if (allValid)
                ProgOps.InsertToDatabase(tbxFirstName, tbxLastName, tbxPhone, tbxEmail, tbxUsername, tbxPassword);
            
            if(!allValid)
            {
                MessageBox.Show(sb.ToString(), "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

           // ProgOps.InsertToDatabase(tbxFirstName, tbxLastName, tbxPhone, tbxEmail, tbxUsername, tbxPassword);
        }

        private void frmSignUp_FormClosing(object sender, FormClosingEventArgs e)
        {
            //Close this form's connection to the database
            ProgOps.CloseDatabase();
        }
    }
}

//while (true)
//{

//    //establish variables (can be done in try for ease and efficency.)
//    //create the object
//    Scanner input2 = new Scanner(System.in);

//    //wrap all of this in a try/catch because we don't know what will work
//    try
//    {
//        int upperCase = 0;
//        int lowerCase = 0;
//        int digit = 0;
//        int symbol = 0;
//        int space = 0;
//        char[] specials = { '{', '!', '@', '#', '$', '%', '&', '*', '(', ')', '+', '-', '.', '/', ':', ';', '<', '=', '>', '?', '[', ']', '^', '_', '`', '{', '|', '}' };

//        //ask for userInput
//        System.out.println("Create a password (must be at least six characters in length) : ");

//        //store userInput
//        String password = input2.nextLine();

//        //test for the criteria it must meet (pw)
//        if (password.length() < 6)
//        {

//            throw new BadInputException(" Password must be at least six characters.");
//        }

//        for (int w = 0; w < password.length(); w++)
//        {

//            if (Character.isWhitespace(password.toCharArray()[w]))
//            {
//                space++;
//            }

//        }

//        for (int i = 0; i < password.length(); i++)
//        {
//            if (Character.isUpperCase(password.toCharArray()[i]))
//            {
//                upperCase++;
//            }
//        }

//        for (int l = 0; l < password.length(); l++)
//        {
//            if (Character.isLowerCase(password.toCharArray()[l]))
//            {
//                lowerCase++;
//            }
//        }

//        for (int d = 0; d < password.length(); d++)
//        {
//            if (Character.isDigit(password.toCharArray()[d]))
//            {
//                digit++;
//            }
//        }

//        for (int i = 0; i < password.length(); i++)
//        {

//            // i is for your password characters
//            for (int j = 0; j < specials.length; j++)
//            {

//                //j is for your special character array
//                if (password.charAt(i) == specials[j])
//                {
//                    symbol++;
//                }
//            }
//        }

//        if (space != 0)
//        {

//            throw new BadInputException("Password may not contain spaces.");
//        }
//        if (upperCase == 0)
//        {
//            throw new BadInputException("Your password must contain one at least uppercase letter.");
//        }
//        if (lowerCase == 0)
//        {
//            throw new BadInputException("Your password must contain at least one lowercase letter.");
//        }
//        if (digit == 0)
//        {
//            throw new BadInputException("Your password must contain at least one digit.");

//        }
//        if (symbol == 0)
//        {
//            throw new BadInputException("Your password must contain at least one special character.");

//        }
//    }
//    catch (BadInputException msg)
//    {
//        System.out.println(msg.toString());

//        //shows the error, and then restarts the loop
//        continue;
//    }

//    //if everything goes well, we break out of the loop
//    break;
//}
//static bool ValidatePassword(string password)
//{
//    const int MIN_LENGTH = 8;
//    const int MAX_LENGTH = 15;

//    if (password == null) throw new ArgumentNullException();

//    bool meetsLengthRequirements = password.Length >= MIN_LENGTH && password.Length <= MAX_LENGTH;
//    bool hasUpperCaseLetter = false;
//    bool hasLowerCaseLetter = false;
//    bool hasDecimalDigit = false;

//    if (meetsLengthRequirements)
//    {
//        foreach (char c in password)
//        {
//            if (char.IsUpper(c)) hasUpperCaseLetter = true;
//            else if (char.IsLower(c)) hasLowerCaseLetter = true;
//            else if (char.IsDigit(c)) hasDecimalDigit = true;
//        }
//    }

//    bool isValid = meetsLengthRequirements
//                && hasUpperCaseLetter
//                && hasLowerCaseLetter
//                && hasDecimalDigit
//                ;
//    return isValid;

//}