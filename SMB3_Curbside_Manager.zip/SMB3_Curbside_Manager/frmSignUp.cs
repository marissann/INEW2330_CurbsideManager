﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EmailValidation;

namespace SMB3_Curbside_Manager
{
    public partial class frmSignUp : Form
    {
        public frmSignUp()
        {
            InitializeComponent();
        }

        private void frmSignUp_Load(object sender, EventArgs e)
        {

        }

        private void btnSignUp_Click(object sender, EventArgs e)
        {

            //bool to confirm if all fields are correctly input
            bool allValid = true;

            //Firstname = 20, Lastname = 20, Phone = 20, Email = 50, User = 20, Password = 20
            //Validation for First Name

            if (tbxFirstName.Text.Trim() == String.Empty || tbxFirstName.Text.Length > 20)
            {
                lblFirstNameError.Visible = true;
                allValid = false;
            }
            else
            {
                lblFirstNameError.Visible = false;
                allValid = true;
            }

            //Validation for Last Name
            if (tbxLastName.Text.Trim() == String.Empty || tbxLastName.Text.Length > 20)
            {
                lblLastNameError.Visible = true;
                allValid = false;
            }
            else
            {
                lblLastNameError.Visible = false;
                allValid = true;
            }

            //Validation for Phone Number
            if (tbxPhone.Text.Trim() == String.Empty)
            {
                //MessageBox.Show("Phone number is empty. Please fill out all fields before continuing.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                lblPhoneError.Visible = false;
                allValid = false;
            }
            else
            {
                lblPhoneError.Visible = false;
                allValid = true;
            }

            //Validation for Email
            if (tbxEmail.Text.Trim() == String.Empty || tbxEmail.Text.Length > 50 || !EmailValidator.Validate(tbxEmail.Text.Trim(), true, true))
            {
                lblEmailError.Visible = true;

                allValid = false;
            }
            else
            {
                lblEmailError.Visible = false;
                allValid = true;
            }

            //Validation for Username
            if (tbxUsername.Text.Trim() == String.Empty || (tbxUsername.Text.Trim().Length > 20))
            {
                lblUsernameError.Visible = true;

                allValid = false;
            }
            else
            {
                lblUsernameError.Visible = false;
                allValid = true;
            }
            
            //bool to tell if password has a number
            bool hasNumber = false;

            for (int i = 0; i < tbxPassword.Text.Trim().Length; i++)
            {
                if (Char.IsDigit(tbxPassword.Text.Trim()[i]))
                {
                    hasNumber = true;
                    break;
                }
            }

            //int to track the number of symbols found in password
            int symbolCtr = 0;

            for (int i = 0; i < tbxPassword.Text.Trim().Length; i++)
            {
                if (Char.IsSymbol(tbxPassword.Text[i]))
                {
                    symbolCtr++;
                }
            }

            //Validation for Password
            if (tbxPassword.Text.Trim() == String.Empty || tbxPassword.Text.Trim().Length > 20 || tbxPassword.Text.Trim().Length < 8 || !hasNumber || symbolCtr < 2)
            {
                lblPasswordError.Visible = true;
                allValid = false;
                Console.WriteLine(symbolCtr);
                Console.WriteLine(hasNumber);
            }
            else
            {
                lblPasswordError.Visible = false;
                allValid = true;
                Console.WriteLine(symbolCtr);
                Console.WriteLine(hasNumber);
            }
            

            //If the entered data is all valid, attempt account creation
            if (allValid == true)
            {
                ProgOps.InsertToDatabase(tbxFirstName, tbxLastName, tbxPhone, tbxEmail, tbxUsername, tbxPassword);
                MessageBox.Show("HEY YO WE DID SOETHING GOOD");
            }
            else
            {
                MessageBox.Show("FUCK");
            }
        }

        private void frmSignUp_FormClosing(object sender, FormClosingEventArgs e)
        {
            //Close this form's connection to the database
            ProgOps.CloseDatabase();
        }

    }
}
