﻿namespace SMB3_Curbside_Manager
{
    partial class frmEmployee_Order_View
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnNewest = new System.Windows.Forms.Button();
            this.btnOldest = new System.Windows.Forms.Button();
            this.btnNext = new System.Windows.Forms.Button();
            this.btnLeft = new System.Windows.Forms.Button();
            this.tbxEmployeeID = new System.Windows.Forms.TextBox();
            this.tbxTotalPrice = new System.Windows.Forms.TextBox();
            this.tbxOrderDate = new System.Windows.Forms.TextBox();
            this.tbxCustomerID = new System.Windows.Forms.TextBox();
            this.tbxOrderID = new System.Windows.Forms.TextBox();
            this.lblPriceText = new System.Windows.Forms.Label();
            this.lblOrderDate = new System.Windows.Forms.Label();
            this.lblQuantityText = new System.Windows.Forms.Label();
            this.lblCustomerIDText = new System.Windows.Forms.Label();
            this.lblOrderID = new System.Windows.Forms.Label();
            this.dgvOrderInfo = new System.Windows.Forms.DataGridView();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnHandle = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvOrderInfo)).BeginInit();
            this.SuspendLayout();
            // 
            // btnNewest
            // 
            this.btnNewest.Location = new System.Drawing.Point(678, 498);
            this.btnNewest.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.btnNewest.Name = "btnNewest";
            this.btnNewest.Size = new System.Drawing.Size(137, 42);
            this.btnNewest.TabIndex = 117;
            this.btnNewest.Text = "Newest";
            this.btnNewest.UseVisualStyleBackColor = true;
            this.btnNewest.Click += new System.EventHandler(this.btnNewest_Click);
            // 
            // btnOldest
            // 
            this.btnOldest.Location = new System.Drawing.Point(98, 498);
            this.btnOldest.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.btnOldest.Name = "btnOldest";
            this.btnOldest.Size = new System.Drawing.Size(137, 42);
            this.btnOldest.TabIndex = 116;
            this.btnOldest.Text = "Oldest";
            this.btnOldest.UseVisualStyleBackColor = true;
            this.btnOldest.Click += new System.EventHandler(this.btnOldest_Click);
            // 
            // btnNext
            // 
            this.btnNext.Location = new System.Drawing.Point(499, 498);
            this.btnNext.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(137, 42);
            this.btnNext.TabIndex = 115;
            this.btnNext.Text = "Next";
            this.btnNext.UseVisualStyleBackColor = true;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // btnLeft
            // 
            this.btnLeft.Location = new System.Drawing.Point(290, 498);
            this.btnLeft.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.btnLeft.Name = "btnLeft";
            this.btnLeft.Size = new System.Drawing.Size(137, 42);
            this.btnLeft.TabIndex = 114;
            this.btnLeft.Text = "Previous";
            this.btnLeft.UseVisualStyleBackColor = true;
            this.btnLeft.Click += new System.EventHandler(this.btnLeft_Click);
            // 
            // tbxEmployeeID
            // 
            this.tbxEmployeeID.Location = new System.Drawing.Point(290, 421);
            this.tbxEmployeeID.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.tbxEmployeeID.Name = "tbxEmployeeID";
            this.tbxEmployeeID.ReadOnly = true;
            this.tbxEmployeeID.Size = new System.Drawing.Size(448, 29);
            this.tbxEmployeeID.TabIndex = 113;
            // 
            // tbxTotalPrice
            // 
            this.tbxTotalPrice.Location = new System.Drawing.Point(290, 325);
            this.tbxTotalPrice.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.tbxTotalPrice.Name = "tbxTotalPrice";
            this.tbxTotalPrice.ReadOnly = true;
            this.tbxTotalPrice.Size = new System.Drawing.Size(448, 29);
            this.tbxTotalPrice.TabIndex = 112;
            // 
            // tbxOrderDate
            // 
            this.tbxOrderDate.Location = new System.Drawing.Point(290, 228);
            this.tbxOrderDate.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.tbxOrderDate.Name = "tbxOrderDate";
            this.tbxOrderDate.ReadOnly = true;
            this.tbxOrderDate.Size = new System.Drawing.Size(448, 29);
            this.tbxOrderDate.TabIndex = 111;
            // 
            // tbxCustomerID
            // 
            this.tbxCustomerID.Location = new System.Drawing.Point(290, 146);
            this.tbxCustomerID.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.tbxCustomerID.Name = "tbxCustomerID";
            this.tbxCustomerID.ReadOnly = true;
            this.tbxCustomerID.Size = new System.Drawing.Size(448, 29);
            this.tbxCustomerID.TabIndex = 110;
            // 
            // tbxOrderID
            // 
            this.tbxOrderID.Location = new System.Drawing.Point(290, 61);
            this.tbxOrderID.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.tbxOrderID.Name = "tbxOrderID";
            this.tbxOrderID.ReadOnly = true;
            this.tbxOrderID.Size = new System.Drawing.Size(448, 29);
            this.tbxOrderID.TabIndex = 109;
            this.tbxOrderID.TextChanged += new System.EventHandler(this.tbxOrderID_TextChanged);
            // 
            // lblPriceText
            // 
            this.lblPriceText.AutoSize = true;
            this.lblPriceText.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPriceText.Location = new System.Drawing.Point(76, 421);
            this.lblPriceText.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblPriceText.Name = "lblPriceText";
            this.lblPriceText.Size = new System.Drawing.Size(169, 29);
            this.lblPriceText.TabIndex = 108;
            this.lblPriceText.Text = "EmployeeID  : ";
            this.lblPriceText.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblOrderDate
            // 
            this.lblOrderDate.AutoSize = true;
            this.lblOrderDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOrderDate.Location = new System.Drawing.Point(76, 228);
            this.lblOrderDate.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblOrderDate.Name = "lblOrderDate";
            this.lblOrderDate.Size = new System.Drawing.Size(150, 29);
            this.lblOrderDate.TabIndex = 107;
            this.lblOrderDate.Text = "Order Date : ";
            this.lblOrderDate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblQuantityText
            // 
            this.lblQuantityText.AutoSize = true;
            this.lblQuantityText.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuantityText.Location = new System.Drawing.Point(76, 325);
            this.lblQuantityText.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblQuantityText.Name = "lblQuantityText";
            this.lblQuantityText.Size = new System.Drawing.Size(148, 29);
            this.lblQuantityText.TabIndex = 106;
            this.lblQuantityText.Text = "Total Price : ";
            this.lblQuantityText.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblCustomerIDText
            // 
            this.lblCustomerIDText.AutoSize = true;
            this.lblCustomerIDText.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCustomerIDText.Location = new System.Drawing.Point(76, 146);
            this.lblCustomerIDText.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblCustomerIDText.Name = "lblCustomerIDText";
            this.lblCustomerIDText.Size = new System.Drawing.Size(158, 29);
            this.lblCustomerIDText.TabIndex = 105;
            this.lblCustomerIDText.Text = "CustomerID : ";
            this.lblCustomerIDText.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblOrderID
            // 
            this.lblOrderID.AutoSize = true;
            this.lblOrderID.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOrderID.Location = new System.Drawing.Point(76, 67);
            this.lblOrderID.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblOrderID.Name = "lblOrderID";
            this.lblOrderID.Size = new System.Drawing.Size(111, 29);
            this.lblOrderID.TabIndex = 104;
            this.lblOrderID.Text = "OrderID :";
            this.lblOrderID.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dgvOrderInfo
            // 
            this.dgvOrderInfo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvOrderInfo.Location = new System.Drawing.Point(876, 41);
            this.dgvOrderInfo.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.dgvOrderInfo.Name = "dgvOrderInfo";
            this.dgvOrderInfo.RowHeadersWidth = 62;
            this.dgvOrderInfo.Size = new System.Drawing.Size(787, 665);
            this.dgvOrderInfo.TabIndex = 103;
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(354, 677);
            this.btnExit.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(183, 74);
            this.btnExit.TabIndex = 102;
            this.btnExit.Text = "E&xit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnHandle
            // 
            this.btnHandle.Location = new System.Drawing.Point(176, 563);
            this.btnHandle.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.btnHandle.Name = "btnHandle";
            this.btnHandle.Size = new System.Drawing.Size(137, 42);
            this.btnHandle.TabIndex = 119;
            this.btnHandle.Text = "Handle Order";
            this.btnHandle.UseVisualStyleBackColor = true;
            this.btnHandle.Click += new System.EventHandler(this.btnHandle_Click);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(379, 563);
            this.btnSave.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(137, 42);
            this.btnSave.TabIndex = 120;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(584, 563);
            this.btnCancel.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(137, 42);
            this.btnCancel.TabIndex = 121;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // frmEmployee_Order_View
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1738, 766);
            this.ControlBox = false;
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnHandle);
            this.Controls.Add(this.btnNewest);
            this.Controls.Add(this.btnOldest);
            this.Controls.Add(this.btnNext);
            this.Controls.Add(this.btnLeft);
            this.Controls.Add(this.tbxEmployeeID);
            this.Controls.Add(this.tbxTotalPrice);
            this.Controls.Add(this.tbxOrderDate);
            this.Controls.Add(this.tbxCustomerID);
            this.Controls.Add(this.tbxOrderID);
            this.Controls.Add(this.lblPriceText);
            this.Controls.Add(this.lblOrderDate);
            this.Controls.Add(this.lblQuantityText);
            this.Controls.Add(this.lblCustomerIDText);
            this.Controls.Add(this.lblOrderID);
            this.Controls.Add(this.dgvOrderInfo);
            this.Controls.Add(this.btnExit);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "frmEmployee_Order_View";
            this.Text = "Employee: Order Details";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmEmployee_Order_View_FormClosing);
            this.Load += new System.EventHandler(this.frmEmployee_Order_View_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvOrderInfo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnNewest;
        private System.Windows.Forms.Button btnOldest;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.Button btnLeft;
        private System.Windows.Forms.TextBox tbxEmployeeID;
        private System.Windows.Forms.TextBox tbxTotalPrice;
        private System.Windows.Forms.TextBox tbxOrderDate;
        private System.Windows.Forms.TextBox tbxCustomerID;
        private System.Windows.Forms.TextBox tbxOrderID;
        private System.Windows.Forms.Label lblPriceText;
        private System.Windows.Forms.Label lblOrderDate;
        private System.Windows.Forms.Label lblQuantityText;
        private System.Windows.Forms.Label lblCustomerIDText;
        private System.Windows.Forms.Label lblOrderID;
        private System.Windows.Forms.DataGridView dgvOrderInfo;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnHandle;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnCancel;
    }
}