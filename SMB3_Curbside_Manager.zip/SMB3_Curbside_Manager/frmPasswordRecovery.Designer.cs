﻿
namespace SMB3_Curbside_Manager
{
    partial class frmPasswordRecovery
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblForgotPasswordText = new System.Windows.Forms.Label();
            this.lblResetText = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblPassword = new System.Windows.Forms.Label();
            this.tbxEmailRecovery = new System.Windows.Forms.TextBox();
            this.btnRecovery = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.lblEmailRecoveryError = new System.Windows.Forms.Label();
            this.Error = new System.Windows.Forms.ToolTip(this.components);
            this.btnLogin = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // lblForgotPasswordText
            // 
            this.lblForgotPasswordText.AutoSize = true;
            this.lblForgotPasswordText.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblForgotPasswordText.Location = new System.Drawing.Point(480, 65);
            this.lblForgotPasswordText.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblForgotPasswordText.Name = "lblForgotPasswordText";
            this.lblForgotPasswordText.Size = new System.Drawing.Size(524, 64);
            this.lblForgotPasswordText.TabIndex = 0;
            this.lblForgotPasswordText.Text = "Password Recovery";
            // 
            // lblResetText
            // 
            this.lblResetText.AutoSize = true;
            this.lblResetText.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResetText.Location = new System.Drawing.Point(504, 132);
            this.lblResetText.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblResetText.Name = "lblResetText";
            this.lblResetText.Size = new System.Drawing.Size(463, 29);
            this.lblResetText.TabIndex = 1;
            this.lblResetText.Text = "Please Enter Email To Recover Password";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Black;
            this.pictureBox1.Location = new System.Drawing.Point(346, 0);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(2, 692);
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // lblPassword
            // 
            this.lblPassword.AutoSize = true;
            this.lblPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPassword.Location = new System.Drawing.Point(488, 363);
            this.lblPassword.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPassword.Name = "lblPassword";
            this.lblPassword.Size = new System.Drawing.Size(92, 29);
            this.lblPassword.TabIndex = 3;
            this.lblPassword.Text = "Email : ";
            // 
            // tbxEmailRecovery
            // 
            this.tbxEmailRecovery.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxEmailRecovery.Location = new System.Drawing.Point(576, 360);
            this.tbxEmailRecovery.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tbxEmailRecovery.Name = "tbxEmailRecovery";
            this.tbxEmailRecovery.Size = new System.Drawing.Size(448, 35);
            this.tbxEmailRecovery.TabIndex = 4;
            this.tbxEmailRecovery.TextChanged += new System.EventHandler(this.tbxEmailRecovery_TextChanged);
            // 
            // btnRecovery
            // 
            this.btnRecovery.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRecovery.Location = new System.Drawing.Point(576, 492);
            this.btnRecovery.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnRecovery.Name = "btnRecovery";
            this.btnRecovery.Size = new System.Drawing.Size(198, 58);
            this.btnRecovery.TabIndex = 5;
            this.btnRecovery.Text = "Send Email";
            this.btnRecovery.UseVisualStyleBackColor = true;
            this.btnRecovery.Click += new System.EventHandler(this.btnRecovery_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::SMB3_Curbside_Manager.Properties.Resources.Discord_TTT_page_001;
            this.pictureBox2.Location = new System.Drawing.Point(4, 0);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(338, 692);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 6;
            this.pictureBox2.TabStop = false;
            // 
            // lblEmailRecoveryError
            // 
            this.lblEmailRecoveryError.AutoSize = true;
            this.lblEmailRecoveryError.ForeColor = System.Drawing.Color.Red;
            this.lblEmailRecoveryError.Location = new System.Drawing.Point(1081, 374);
            this.lblEmailRecoveryError.Name = "lblEmailRecoveryError";
            this.lblEmailRecoveryError.Size = new System.Drawing.Size(44, 20);
            this.lblEmailRecoveryError.TabIndex = 7;
            this.lblEmailRecoveryError.Text = "Error";
            this.Error.SetToolTip(this.lblEmailRecoveryError, "Error");
            // 
            // Error
            // 
            this.Error.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Error;
            this.Error.ToolTipTitle = "ttError";
            // 
            // btnLogin
            // 
            this.btnLogin.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogin.Location = new System.Drawing.Point(859, 492);
            this.btnLogin.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Size = new System.Drawing.Size(198, 58);
            this.btnLogin.TabIndex = 8;
            this.btnLogin.Text = "Return to Login";
            this.btnLogin.UseVisualStyleBackColor = true;
            this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click);
            // 
            // frmPasswordRecovery
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1200, 692);
            this.ControlBox = false;
            this.Controls.Add(this.btnLogin);
            this.Controls.Add(this.lblEmailRecoveryError);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.btnRecovery);
            this.Controls.Add(this.tbxEmailRecovery);
            this.Controls.Add(this.lblPassword);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.lblResetText);
            this.Controls.Add(this.lblForgotPasswordText);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "frmPasswordRecovery";
            this.Text = "frmPasswordRecovery";
            this.Load += new System.EventHandler(this.frmPasswordRecovery_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblForgotPasswordText;
        private System.Windows.Forms.Label lblResetText;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblPassword;
        private System.Windows.Forms.TextBox tbxEmailRecovery;
        private System.Windows.Forms.Button btnRecovery;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label lblEmailRecoveryError;
        private System.Windows.Forms.ToolTip Error;
        private System.Windows.Forms.Button btnLogin;
    }
}