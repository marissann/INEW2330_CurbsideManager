﻿
namespace SMB3_Curbside_Manager
{
    partial class frmAdmin_Employee_View
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmAdmin_Employee_View));
            this.tbxPassword = new System.Windows.Forms.TextBox();
            this.tbxUserName = new System.Windows.Forms.TextBox();
            this.tbxLastName = new System.Windows.Forms.TextBox();
            this.tbxFirstName = new System.Windows.Forms.TextBox();
            this.tbxEmployeeID = new System.Windows.Forms.TextBox();
            this.btnLast = new System.Windows.Forms.Button();
            this.btnFirst = new System.Windows.Forms.Button();
            this.btnNext = new System.Windows.Forms.Button();
            this.btnPrevious = new System.Windows.Forms.Button();
            this.lblLastNameText = new System.Windows.Forms.Label();
            this.lblHireDateText = new System.Windows.Forms.Label();
            this.lblPasswordText = new System.Windows.Forms.Label();
            this.lblFirstNameText = new System.Windows.Forms.Label();
            this.lblEnployeeUsernameText = new System.Windows.Forms.Label();
            this.lblEmployeeIDText = new System.Windows.Forms.Label();
            this.tbxHireDate = new System.Windows.Forms.TextBox();
            this.lblIsADminText = new System.Windows.Forms.Label();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnEdit = new System.Windows.Forms.Button();
            this.btnAddNew = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.tbxIsAdmin = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // tbxPassword
            // 
            this.tbxPassword.Location = new System.Drawing.Point(148, 121);
            this.tbxPassword.Name = "tbxPassword";
            this.tbxPassword.Size = new System.Drawing.Size(270, 20);
            this.tbxPassword.TabIndex = 76;
            this.tbxPassword.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbxPassword_KeyPress);
            // 
            // tbxUserName
            // 
            this.tbxUserName.Location = new System.Drawing.Point(148, 69);
            this.tbxUserName.Name = "tbxUserName";
            this.tbxUserName.Size = new System.Drawing.Size(270, 20);
            this.tbxUserName.TabIndex = 75;
            this.tbxUserName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbxUserName_KeyPress);
            // 
            // tbxLastName
            // 
            this.tbxLastName.Location = new System.Drawing.Point(148, 219);
            this.tbxLastName.Name = "tbxLastName";
            this.tbxLastName.Size = new System.Drawing.Size(270, 20);
            this.tbxLastName.TabIndex = 74;
            this.tbxLastName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbxLastName_KeyPress);
            // 
            // tbxFirstName
            // 
            this.tbxFirstName.Location = new System.Drawing.Point(148, 175);
            this.tbxFirstName.Name = "tbxFirstName";
            this.tbxFirstName.Size = new System.Drawing.Size(270, 20);
            this.tbxFirstName.TabIndex = 73;
            this.tbxFirstName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbxFirstName_KeyPress);
            // 
            // tbxEmployeeID
            // 
            this.tbxEmployeeID.Location = new System.Drawing.Point(148, 31);
            this.tbxEmployeeID.Name = "tbxEmployeeID";
            this.tbxEmployeeID.Size = new System.Drawing.Size(270, 20);
            this.tbxEmployeeID.TabIndex = 72;
            // 
            // btnLast
            // 
            this.btnLast.Location = new System.Drawing.Point(343, 331);
            this.btnLast.Name = "btnLast";
            this.btnLast.Size = new System.Drawing.Size(75, 23);
            this.btnLast.TabIndex = 70;
            this.btnLast.Text = "Last";
            this.btnLast.UseVisualStyleBackColor = true;
            this.btnLast.Click += new System.EventHandler(this.btnLast_Click);
            // 
            // btnFirst
            // 
            this.btnFirst.Location = new System.Drawing.Point(240, 331);
            this.btnFirst.Name = "btnFirst";
            this.btnFirst.Size = new System.Drawing.Size(75, 23);
            this.btnFirst.TabIndex = 69;
            this.btnFirst.Text = "First";
            this.btnFirst.UseVisualStyleBackColor = true;
            this.btnFirst.Click += new System.EventHandler(this.btnFirst_Click);
            // 
            // btnNext
            // 
            this.btnNext.Location = new System.Drawing.Point(128, 331);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(75, 23);
            this.btnNext.TabIndex = 68;
            this.btnNext.Text = "Next";
            this.btnNext.UseVisualStyleBackColor = true;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // btnPrevious
            // 
            this.btnPrevious.Location = new System.Drawing.Point(24, 331);
            this.btnPrevious.Name = "btnPrevious";
            this.btnPrevious.Size = new System.Drawing.Size(75, 23);
            this.btnPrevious.TabIndex = 67;
            this.btnPrevious.Text = "Previous";
            this.btnPrevious.UseVisualStyleBackColor = true;
            this.btnPrevious.Click += new System.EventHandler(this.btnPrevious_Click);
            // 
            // lblLastNameText
            // 
            this.lblLastNameText.AutoSize = true;
            this.lblLastNameText.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLastNameText.Location = new System.Drawing.Point(27, 219);
            this.lblLastNameText.Name = "lblLastNameText";
            this.lblLastNameText.Size = new System.Drawing.Size(85, 16);
            this.lblLastNameText.TabIndex = 66;
            this.lblLastNameText.Text = "Last Name :  ";
            // 
            // lblHireDateText
            // 
            this.lblHireDateText.AutoSize = true;
            this.lblHireDateText.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHireDateText.Location = new System.Drawing.Point(29, 260);
            this.lblHireDateText.Name = "lblHireDateText";
            this.lblHireDateText.Size = new System.Drawing.Size(74, 16);
            this.lblHireDateText.TabIndex = 65;
            this.lblHireDateText.Text = "Hire Date : ";
            // 
            // lblPasswordText
            // 
            this.lblPasswordText.AutoSize = true;
            this.lblPasswordText.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPasswordText.Location = new System.Drawing.Point(34, 121);
            this.lblPasswordText.Name = "lblPasswordText";
            this.lblPasswordText.Size = new System.Drawing.Size(74, 16);
            this.lblPasswordText.TabIndex = 64;
            this.lblPasswordText.Text = "Password :";
            // 
            // lblFirstNameText
            // 
            this.lblFirstNameText.AutoSize = true;
            this.lblFirstNameText.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFirstNameText.Location = new System.Drawing.Point(29, 175);
            this.lblFirstNameText.Name = "lblFirstNameText";
            this.lblFirstNameText.Size = new System.Drawing.Size(82, 16);
            this.lblFirstNameText.TabIndex = 63;
            this.lblFirstNameText.Text = "First Name : ";
            // 
            // lblEnployeeUsernameText
            // 
            this.lblEnployeeUsernameText.AutoSize = true;
            this.lblEnployeeUsernameText.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEnployeeUsernameText.Location = new System.Drawing.Point(29, 69);
            this.lblEnployeeUsernameText.Name = "lblEnployeeUsernameText";
            this.lblEnployeeUsernameText.Size = new System.Drawing.Size(80, 16);
            this.lblEnployeeUsernameText.TabIndex = 62;
            this.lblEnployeeUsernameText.Text = "Username : ";
            // 
            // lblEmployeeIDText
            // 
            this.lblEmployeeIDText.AutoSize = true;
            this.lblEmployeeIDText.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmployeeIDText.Location = new System.Drawing.Point(29, 31);
            this.lblEmployeeIDText.Name = "lblEmployeeIDText";
            this.lblEmployeeIDText.Size = new System.Drawing.Size(92, 16);
            this.lblEmployeeIDText.TabIndex = 61;
            this.lblEmployeeIDText.Text = "EmployeeID : ";
            // 
            // tbxHireDate
            // 
            this.tbxHireDate.Location = new System.Drawing.Point(148, 260);
            this.tbxHireDate.Name = "tbxHireDate";
            this.tbxHireDate.Size = new System.Drawing.Size(270, 20);
            this.tbxHireDate.TabIndex = 77;
            // 
            // lblIsADminText
            // 
            this.lblIsADminText.AutoSize = true;
            this.lblIsADminText.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIsADminText.Location = new System.Drawing.Point(29, 298);
            this.lblIsADminText.Name = "lblIsADminText";
            this.lblIsADminText.Size = new System.Drawing.Size(68, 16);
            this.lblIsADminText.TabIndex = 78;
            this.lblIsADminText.Text = "Is Admin : ";
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(343, 360);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 83;
            this.btnCancel.Text = "&Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(240, 360);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 82;
            this.btnSave.Text = "&Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnEdit
            // 
            this.btnEdit.Location = new System.Drawing.Point(128, 360);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(75, 23);
            this.btnEdit.TabIndex = 81;
            this.btnEdit.Text = "&Edit";
            this.btnEdit.UseVisualStyleBackColor = true;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // btnAddNew
            // 
            this.btnAddNew.Location = new System.Drawing.Point(24, 360);
            this.btnAddNew.Name = "btnAddNew";
            this.btnAddNew.Size = new System.Drawing.Size(75, 23);
            this.btnAddNew.TabIndex = 80;
            this.btnAddNew.Text = "&Add New";
            this.btnAddNew.UseVisualStyleBackColor = true;
            this.btnAddNew.Click += new System.EventHandler(this.btnAddNew_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(128, 389);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(75, 23);
            this.btnDelete.TabIndex = 79;
            this.btnDelete.Text = "&Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(240, 389);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 84;
            this.btnClose.Text = "C&lose";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // tbxIsAdmin
            // 
            this.tbxIsAdmin.Location = new System.Drawing.Point(148, 298);
            this.tbxIsAdmin.Name = "tbxIsAdmin";
            this.tbxIsAdmin.Size = new System.Drawing.Size(270, 20);
            this.tbxIsAdmin.TabIndex = 85;
            this.tbxIsAdmin.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbxIsAdmin_KeyPress);
            // 
            // frmAdmin_Employee_View
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(473, 434);
            this.ControlBox = false;
            this.Controls.Add(this.tbxIsAdmin);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnEdit);
            this.Controls.Add(this.btnAddNew);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.lblIsADminText);
            this.Controls.Add(this.tbxHireDate);
            this.Controls.Add(this.tbxPassword);
            this.Controls.Add(this.tbxUserName);
            this.Controls.Add(this.tbxLastName);
            this.Controls.Add(this.tbxFirstName);
            this.Controls.Add(this.tbxEmployeeID);
            this.Controls.Add(this.btnLast);
            this.Controls.Add(this.btnFirst);
            this.Controls.Add(this.btnNext);
            this.Controls.Add(this.btnPrevious);
            this.Controls.Add(this.lblLastNameText);
            this.Controls.Add(this.lblHireDateText);
            this.Controls.Add(this.lblPasswordText);
            this.Controls.Add(this.lblFirstNameText);
            this.Controls.Add(this.lblEnployeeUsernameText);
            this.Controls.Add(this.lblEmployeeIDText);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmAdmin_Employee_View";
            this.Text = "Admin: View Employees";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmAdmin_Employee_View_FormClosing);
            this.Load += new System.EventHandler(this.frmAdmin_Employee_View_Load);
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.frmAdmin_Employee_View_KeyPress);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbxPassword;
        private System.Windows.Forms.TextBox tbxUserName;
        private System.Windows.Forms.TextBox tbxLastName;
        private System.Windows.Forms.TextBox tbxFirstName;
        private System.Windows.Forms.TextBox tbxEmployeeID;
        private System.Windows.Forms.Button btnLast;
        private System.Windows.Forms.Button btnFirst;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.Button btnPrevious;
        private System.Windows.Forms.Label lblLastNameText;
        private System.Windows.Forms.Label lblHireDateText;
        private System.Windows.Forms.Label lblPasswordText;
        private System.Windows.Forms.Label lblFirstNameText;
        private System.Windows.Forms.Label lblEnployeeUsernameText;
        private System.Windows.Forms.Label lblEmployeeIDText;
        private System.Windows.Forms.TextBox tbxHireDate;
        private System.Windows.Forms.Label lblIsADminText;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnEdit;
        private System.Windows.Forms.Button btnAddNew;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.TextBox tbxIsAdmin;
    }
}