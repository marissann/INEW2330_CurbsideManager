﻿
namespace SMB3_Curbside_Manager
{
    partial class frmCustomer_Merchandise_View
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmbCategory = new System.Windows.Forms.ComboBox();
            this.dgvMerchandise = new System.Windows.Forms.DataGridView();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnSearch = new System.Windows.Forms.Button();
            this.lblcategoryText = new System.Windows.Forms.Label();
            this.lbltextID = new System.Windows.Forms.Label();
            this.tbxMerchandiseID = new System.Windows.Forms.TextBox();
            this.lblLine = new System.Windows.Forms.Label();
            this.lblMerchandiseInformation = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMerchandise)).BeginInit();
            this.SuspendLayout();
            // 
            // cmbCategory
            // 
            this.cmbCategory.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCategory.FormattingEnabled = true;
            this.cmbCategory.Items.AddRange(new object[] {
            "Dairy",
            "Grain",
            "Meat",
            "Produce",
            "Seafood"});
            this.cmbCategory.Location = new System.Drawing.Point(276, 223);
            this.cmbCategory.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cmbCategory.Name = "cmbCategory";
            this.cmbCategory.Size = new System.Drawing.Size(196, 28);
            this.cmbCategory.TabIndex = 23;
            // 
            // dgvMerchandise
            // 
            this.dgvMerchandise.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvMerchandise.Location = new System.Drawing.Point(674, 18);
            this.dgvMerchandise.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dgvMerchandise.Name = "dgvMerchandise";
            this.dgvMerchandise.RowHeadersWidth = 72;
            this.dgvMerchandise.Size = new System.Drawing.Size(788, 655);
            this.dgvMerchandise.TabIndex = 22;
            // 
            // btnExit
            // 
            this.btnExit.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(165, 575);
            this.btnExit.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(150, 62);
            this.btnExit.TabIndex = 21;
            this.btnExit.Text = "E&xit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnSearch
            // 
            this.btnSearch.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearch.Location = new System.Drawing.Point(324, 575);
            this.btnSearch.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(150, 62);
            this.btnSearch.TabIndex = 20;
            this.btnSearch.Text = "&Display";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // lblcategoryText
            // 
            this.lblcategoryText.AutoSize = true;
            this.lblcategoryText.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcategoryText.Location = new System.Drawing.Point(135, 226);
            this.lblcategoryText.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblcategoryText.Name = "lblcategoryText";
            this.lblcategoryText.Size = new System.Drawing.Size(132, 29);
            this.lblcategoryText.TabIndex = 19;
            this.lblcategoryText.Text = "Category : ";
            // 
            // lbltextID
            // 
            this.lbltextID.AutoSize = true;
            this.lbltextID.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltextID.Location = new System.Drawing.Point(135, 145);
            this.lbltextID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbltextID.Name = "lbltextID";
            this.lbltextID.Size = new System.Drawing.Size(114, 29);
            this.lbltextID.TabIndex = 18;
            this.lbltextID.Text = "Food ID :";
            // 
            // tbxMerchandiseID
            // 
            this.tbxMerchandiseID.Location = new System.Drawing.Point(276, 148);
            this.tbxMerchandiseID.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tbxMerchandiseID.Name = "tbxMerchandiseID";
            this.tbxMerchandiseID.Size = new System.Drawing.Size(196, 26);
            this.tbxMerchandiseID.TabIndex = 17;
            // 
            // lblLine
            // 
            this.lblLine.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblLine.Location = new System.Drawing.Point(8, 65);
            this.lblLine.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblLine.Name = "lblLine";
            this.lblLine.Size = new System.Drawing.Size(657, 5);
            this.lblLine.TabIndex = 24;
            // 
            // lblMerchandiseInformation
            // 
            this.lblMerchandiseInformation.AutoSize = true;
            this.lblMerchandiseInformation.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMerchandiseInformation.Location = new System.Drawing.Point(158, 18);
            this.lblMerchandiseInformation.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMerchandiseInformation.Name = "lblMerchandiseInformation";
            this.lblMerchandiseInformation.Size = new System.Drawing.Size(371, 39);
            this.lblMerchandiseInformation.TabIndex = 25;
            this.lblMerchandiseInformation.Text = "Merchandise Information";
            this.lblMerchandiseInformation.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // frmCustomer_Merchandise_View
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1497, 692);
            this.ControlBox = false;
            this.Controls.Add(this.lblLine);
            this.Controls.Add(this.lblMerchandiseInformation);
            this.Controls.Add(this.cmbCategory);
            this.Controls.Add(this.dgvMerchandise);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.lblcategoryText);
            this.Controls.Add(this.lbltextID);
            this.Controls.Add(this.tbxMerchandiseID);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "frmCustomer_Merchandise_View";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Merchandise Information";
            this.Load += new System.EventHandler(this.frmCustomer_Merchandise_View_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvMerchandise)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cmbCategory;
        private System.Windows.Forms.DataGridView dgvMerchandise;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Label lblcategoryText;
        private System.Windows.Forms.Label lbltextID;
        private System.Windows.Forms.TextBox tbxMerchandiseID;
        private System.Windows.Forms.Label lblLine;
        private System.Windows.Forms.Label lblMerchandiseInformation;
    }
}