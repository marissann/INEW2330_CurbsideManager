﻿
namespace SMB3_Curbside_Manager
{
    partial class frmCustomer_Merchandise_View
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmbCategory = new System.Windows.Forms.ComboBox();
            this.dgvMerchandise = new System.Windows.Forms.DataGridView();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnSearch = new System.Windows.Forms.Button();
            this.lblcategoryText = new System.Windows.Forms.Label();
            this.lbltextID = new System.Windows.Forms.Label();
            this.tbxMerchandiseID = new System.Windows.Forms.TextBox();
            this.lblLine = new System.Windows.Forms.Label();
            this.lblMerchandiseInformation = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMerchandise)).BeginInit();
            this.SuspendLayout();
            // 
            // cmbCategory
            // 
            this.cmbCategory.FormattingEnabled = true;
            this.cmbCategory.Items.AddRange(new object[] {
            "Dairy",
            "Grain",
            "Meat",
            "Produce",
            "Seafood"});
            this.cmbCategory.Location = new System.Drawing.Point(184, 145);
            this.cmbCategory.Name = "cmbCategory";
            this.cmbCategory.Size = new System.Drawing.Size(132, 21);
            this.cmbCategory.TabIndex = 23;
            // 
            // dgvMerchandise
            // 
            this.dgvMerchandise.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvMerchandise.Location = new System.Drawing.Point(449, 12);
            this.dgvMerchandise.Name = "dgvMerchandise";
            this.dgvMerchandise.RowHeadersWidth = 72;
            this.dgvMerchandise.Size = new System.Drawing.Size(525, 426);
            this.dgvMerchandise.TabIndex = 22;
            // 
            // btnExit
            // 
            this.btnExit.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(110, 374);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(100, 40);
            this.btnExit.TabIndex = 21;
            this.btnExit.Text = "E&xit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnSearch
            // 
            this.btnSearch.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearch.Location = new System.Drawing.Point(216, 374);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(100, 40);
            this.btnSearch.TabIndex = 20;
            this.btnSearch.Text = "&Display";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // lblcategoryText
            // 
            this.lblcategoryText.AutoSize = true;
            this.lblcategoryText.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcategoryText.Location = new System.Drawing.Point(90, 147);
            this.lblcategoryText.Name = "lblcategoryText";
            this.lblcategoryText.Size = new System.Drawing.Size(88, 19);
            this.lblcategoryText.TabIndex = 19;
            this.lblcategoryText.Text = "Category : ";
            // 
            // lbltextID
            // 
            this.lbltextID.AutoSize = true;
            this.lbltextID.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltextID.Location = new System.Drawing.Point(90, 94);
            this.lbltextID.Name = "lbltextID";
            this.lbltextID.Size = new System.Drawing.Size(77, 19);
            this.lbltextID.TabIndex = 18;
            this.lbltextID.Text = "Food ID :";
            // 
            // tbxMerchandiseID
            // 
            this.tbxMerchandiseID.Location = new System.Drawing.Point(184, 96);
            this.tbxMerchandiseID.Name = "tbxMerchandiseID";
            this.tbxMerchandiseID.Size = new System.Drawing.Size(132, 20);
            this.tbxMerchandiseID.TabIndex = 17;
            // 
            // lblLine
            // 
            this.lblLine.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblLine.Location = new System.Drawing.Point(5, 42);
            this.lblLine.Name = "lblLine";
            this.lblLine.Size = new System.Drawing.Size(438, 3);
            this.lblLine.TabIndex = 24;
            // 
            // lblMerchandiseInformation
            // 
            this.lblMerchandiseInformation.AutoSize = true;
            this.lblMerchandiseInformation.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMerchandiseInformation.Location = new System.Drawing.Point(105, 12);
            this.lblMerchandiseInformation.Name = "lblMerchandiseInformation";
            this.lblMerchandiseInformation.Size = new System.Drawing.Size(234, 25);
            this.lblMerchandiseInformation.TabIndex = 25;
            this.lblMerchandiseInformation.Text = "Merchadise Information";
            this.lblMerchandiseInformation.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // frmCustomer_Merchandise_View
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(998, 450);
            this.ControlBox = false;
            this.Controls.Add(this.lblLine);
            this.Controls.Add(this.lblMerchandiseInformation);
            this.Controls.Add(this.cmbCategory);
            this.Controls.Add(this.dgvMerchandise);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.lblcategoryText);
            this.Controls.Add(this.lbltextID);
            this.Controls.Add(this.tbxMerchandiseID);
            this.Name = "frmCustomer_Merchandise_View";
            this.Text = "Merchandise Information";
            this.Load += new System.EventHandler(this.frmCustomer_Merchandise_View_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvMerchandise)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cmbCategory;
        private System.Windows.Forms.DataGridView dgvMerchandise;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Label lblcategoryText;
        private System.Windows.Forms.Label lbltextID;
        private System.Windows.Forms.TextBox tbxMerchandiseID;
        private System.Windows.Forms.Label lblLine;
        private System.Windows.Forms.Label lblMerchandiseInformation;
    }
}