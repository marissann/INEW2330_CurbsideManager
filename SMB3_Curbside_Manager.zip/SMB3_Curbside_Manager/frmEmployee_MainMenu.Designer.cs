﻿
namespace SMB3_Curbside_Manager
{
    partial class frmEmployee_MainMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnExit = new System.Windows.Forms.Button();
            this.lblUserId = new System.Windows.Forms.Label();
            this.lblWelcomeUserText = new System.Windows.Forms.Label();
            this.lblBlackLine = new System.Windows.Forms.Label();
            this.btnMerchandiseView = new System.Windows.Forms.Button();
            this.btnOrderView = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(518, 670);
            this.btnExit.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(183, 74);
            this.btnExit.TabIndex = 19;
            this.btnExit.Text = "E&xit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // lblUserId
            // 
            this.lblUserId.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUserId.Location = new System.Drawing.Point(233, 15);
            this.lblUserId.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblUserId.Name = "lblUserId";
            this.lblUserId.Size = new System.Drawing.Size(291, 42);
            this.lblUserId.TabIndex = 18;
            this.lblUserId.Text = "valued employee";
            this.lblUserId.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblUserId.Click += new System.EventHandler(this.lblUserId_Click);
            // 
            // lblWelcomeUserText
            // 
            this.lblWelcomeUserText.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWelcomeUserText.Location = new System.Drawing.Point(37, 15);
            this.lblWelcomeUserText.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblWelcomeUserText.Name = "lblWelcomeUserText";
            this.lblWelcomeUserText.Size = new System.Drawing.Size(184, 42);
            this.lblWelcomeUserText.TabIndex = 17;
            this.lblWelcomeUserText.Text = "Welcome : ";
            // 
            // lblBlackLine
            // 
            this.lblBlackLine.BackColor = System.Drawing.Color.Black;
            this.lblBlackLine.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblBlackLine.Location = new System.Drawing.Point(-7, 72);
            this.lblBlackLine.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblBlackLine.Name = "lblBlackLine";
            this.lblBlackLine.Size = new System.Drawing.Size(1483, 2);
            this.lblBlackLine.TabIndex = 16;
            this.lblBlackLine.Text = "lblBlackLine";
            this.lblBlackLine.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // btnMerchandiseView
            // 
            this.btnMerchandiseView.Location = new System.Drawing.Point(274, 415);
            this.btnMerchandiseView.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.btnMerchandiseView.Name = "btnMerchandiseView";
            this.btnMerchandiseView.Size = new System.Drawing.Size(183, 85);
            this.btnMerchandiseView.TabIndex = 15;
            this.btnMerchandiseView.Text = "Merchandise Info";
            this.btnMerchandiseView.UseVisualStyleBackColor = true;
            this.btnMerchandiseView.Click += new System.EventHandler(this.btnMerchandiseView_Click);
            // 
            // btnOrderView
            // 
            this.btnOrderView.Location = new System.Drawing.Point(274, 260);
            this.btnOrderView.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.btnOrderView.Name = "btnOrderView";
            this.btnOrderView.Size = new System.Drawing.Size(183, 85);
            this.btnOrderView.TabIndex = 14;
            this.btnOrderView.Text = "View Orders";
            this.btnOrderView.UseVisualStyleBackColor = true;
            this.btnOrderView.Click += new System.EventHandler(this.btnOrderView_Click);
            // 
            // frmEmployee_MainMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(731, 761);
            this.ControlBox = false;
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.lblUserId);
            this.Controls.Add(this.lblWelcomeUserText);
            this.Controls.Add(this.lblBlackLine);
            this.Controls.Add(this.btnMerchandiseView);
            this.Controls.Add(this.btnOrderView);
            this.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.Name = "frmEmployee_MainMenu";
            this.Text = "Main Menu";
            this.Load += new System.EventHandler(this.frmEmployee_MainMenu_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label lblUserId;
        private System.Windows.Forms.Label lblWelcomeUserText;
        private System.Windows.Forms.Label lblBlackLine;
        private System.Windows.Forms.Button btnMerchandiseView;
        private System.Windows.Forms.Button btnOrderView;
    }
}