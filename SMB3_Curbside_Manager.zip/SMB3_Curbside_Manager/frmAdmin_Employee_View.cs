﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SMB3_Curbside_Manager
{
    public partial class frmAdmin_Employee_View : Form
    {
        public frmAdmin_Employee_View()
        {
            InitializeComponent();
        }

        //Set up employee CurrencyManager
        CurrencyManager employeeManager;

        //Future variables for state and bookmark
        string myState = "";
        int myBookmark = 0;

        private void frmAdmin_Employee_View_Load(object sender, EventArgs e)
        {
            lblUserId.Text = ProgOps.userFirstName;

            DateTime localDate = DateTime.Now;
            lblDate.Text = localDate.ToString();

            //Load in the Employees table from the database
            ProgOps.FetchEmployees(tbxEmployeeID, tbxUserName, tbxPassword, tbxFirstName, tbxLastName, tbxHireDate, tbxIsAdmin, tbxIsActive);

            //Fill the currency manager
            employeeManager = (CurrencyManager)this.BindingContext[ProgOps.GetEmployeeTable];

            SetState("View");

       


        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            //Move forward one entry
            if (employeeManager.Position != employeeManager.Count - 1)
                employeeManager.Position++;
        }
        private void btnPrevious_Click(object sender, EventArgs e)
        {
            //Move back one entry
            if  (employeeManager.Position != 0)
                employeeManager.Position--;
        }
        private void btnFirst_Click(object sender, EventArgs e)
        {
            //Move to the first entry
            employeeManager.Position = 0;
        }
        private void btnLast_Click(object sender, EventArgs e)
        {
            //Move to the last entry
            employeeManager.Position = employeeManager.Count - 1;
        }
        private void btnAddNew_Click(object sender, EventArgs e)
        {
            try
            {
                myBookmark = employeeManager.Position;
                employeeManager.AddNew();
                SetState("Add");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error : In Add New ", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }
        private void btnEdit_Click(object sender, EventArgs e)
        {
            //Set the form into "Edit" mode
            SetState("Edit");
        }
        private void btnSave_Click(object sender, EventArgs e)
        {
            if (DataIsValid(tbxUserName.Text, tbxPassword.Text, tbxFirstName.Text, tbxLastName.Text,
                           tbxHireDate.Text.Trim(), tbxIsAdmin.Text, tbxIsActive.Text))
            {
                //variables to hold save data
                string savedName = tbxFirstName.Text;
                int savedRow;

                //Have the currency manager end the edit and re-sort the table
                employeeManager.EndCurrentEdit();
                ProgOps.GetEmployeeTable.DefaultView.Sort = "FirstName";

                savedRow = ProgOps.GetEmployeeTable.DefaultView.Find(savedName);

                employeeManager.Position = savedRow;

                //Return to view state
                SetState("View");

                //Display confirming message box
                MessageBox.Show("Record saved successfully.", "Save Record", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        private void btnCancel_Click(object sender, EventArgs e)
        {
            //Cancel the edit
            employeeManager.CancelCurrentEdit();

            //If cancelling from adding an entry, return to saved position
            if (myState == "Add")
                employeeManager.Position = myBookmark;

            //Return to view mode
            SetState("View");
        }
        
        private void btnClose_Click(object sender, EventArgs e)
        {
            //Close the form
            this.Close();
        }      
        private void SetState(string state)
        {
            myState = state;

            switch (state)
            {
                case "View":
                    //Buttons
                    btnPrevious.Enabled = true;
                    btnNext.Enabled = true;
                    btnLast.Enabled = true;
                    btnFirst.Enabled = true;
                    btnAddNew.Enabled = true;
                    btnEdit.Enabled = true;
                    btnSave.Enabled = false;
                    btnCancel.Enabled = false;
                    btnClose.Enabled = true;
                    //textbox
                    tbxEmployeeID.BackColor = Color.White;
                    tbxUserName.ReadOnly = true;
                    tbxPassword.ReadOnly = true;
                    tbxFirstName.ReadOnly = true;
                    tbxLastName.ReadOnly = true;
                    tbxHireDate.ReadOnly = true;
                    tbxIsAdmin.ReadOnly = true;
                    break;
                default:
                    //Buttons
                    btnPrevious.Enabled = false;
                    btnNext.Enabled = false;
                    btnLast.Enabled = false;
                    btnFirst.Enabled = false;
                    btnAddNew.Enabled = false;
                    btnEdit.Enabled = false;
                    btnSave.Enabled = true;
                    btnCancel.Enabled = true;
                    btnClose.Enabled = false;
                    //textbox
                    tbxEmployeeID.BackColor = Color.Red;
                    tbxUserName.ReadOnly = false;
                    tbxPassword.ReadOnly = false;
                    tbxFirstName.ReadOnly = false;
                    tbxLastName.ReadOnly = false;
                    tbxHireDate.ReadOnly = false;
                    tbxIsAdmin.ReadOnly = false;
                    break;
            }

        }

        private void frmAdmin_Employee_View_FormClosing(object sender, FormClosingEventArgs e)
        {
            //Check if the user is not in view mode
            if (myState != "View")
            {
                //Display notification and cancel close
                MessageBox.Show("You must finish the current edit before closing the application.", "Finish Edit",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                e.Cancel = true;
            }
            else
            {
                //Update database
                ProgOps.UpdateEmployeeOnClose();
                ProgOps.DisposeEmployeeObjects();
            }
        }

        private void frmAdmin_Employee_View_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void tbxUserName_KeyPress(object sender, KeyPressEventArgs e)
        {
            //Only allow letters, numbers and backspace
            if(e.KeyChar >= 65 && e.KeyChar <= 90 ||        //ASCII Check for Capital Letters
               e.KeyChar >= 97 && e.KeyChar <= 122 ||       //ASCII Check for Lowercase Letters
               e.KeyChar >= 48 && e.KeyChar <= 57 ||        //ASCII Check for Numbers
               e.KeyChar == 8)                              //ASCII Check for Backspace
            {
                //Accept the keystroke
                e.Handled = false;
            }
            else
            {
                //Deny the keystroke
                e.Handled = true;
            }
        }

        private void tbxPassword_KeyPress(object sender, KeyPressEventArgs e)
        {
            //For passwords, only reject spaces
            if(e.KeyChar == 32)                             //ASCII Check for Space
            {
                //Deny the space
                e.Handled = true;
            }
            else
            {
                //Accept the keystroke
                e.Handled = false;
            }
        }

        private void tbxFirstName_KeyPress(object sender, KeyPressEventArgs e)
        {
            //Only allow letters and backspace
            if (e.KeyChar >= 65 && e.KeyChar <= 90 ||       //ASCII Check for Capital Letters
               e.KeyChar >= 97 && e.KeyChar <= 122 ||       //ASCII Check for Lowercase Letters
               e.KeyChar == 8)                              //ASCII Check for Backspace
            {
                //Convert first letter to uppercase if a lowercase letter was entered
                if (tbxFirstName.Text.Length == 0 && e.KeyChar >= 97 && e.KeyChar <= 122)
                {
                    //Reject the key and replace input with a capital version
                    e.Handled = true;
                    tbxFirstName.Text += e.KeyChar.ToString().ToUpper();

                    //Fixes the text cursor going behind the new character
                    tbxFirstName.Select(1, 0);
                }
                else
                {
                    //Keystrokes are accepted
                    e.Handled = false;
                }
            }
            else
            {
                //Deny the keystroke
                e.Handled = true;
            }
        }

        private void tbxLastName_KeyPress(object sender, KeyPressEventArgs e)
        {
            //Only allow letters and backspace
            if (e.KeyChar >= 65 && e.KeyChar <= 90 ||       //ASCII Check for Capital Letters
               e.KeyChar >= 97 && e.KeyChar <= 122 ||       //ASCII Check for Lowercase Letters
               e.KeyChar == 8)                              //ASCII Check for Backspace
            {
                //Convert first letter to uppercase if a lowercase letter was entered
                if (tbxLastName.Text.Length == 0 && e.KeyChar >= 97 && e.KeyChar <= 122)
                {
                    //Reject the key and replace input with a capitol version
                    e.Handled = true;
                    tbxLastName.Text += e.KeyChar.ToString().ToUpper();

                    //Fixes the text cursor going behind the new character
                    tbxLastName.Select(1, 0);
                }
                else
                {
                    //Keystrokes are accepted
                    e.Handled = false;
                }
            }
            else
            {
                //Deny the keystroke
                e.Handled = true;
            }
        }

        private void tbxHireDate_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(e.KeyChar >= 48 && e.KeyChar <= 57 ||        //ASCII Check for Numbers
               e.KeyChar == 47 ||                           //ASCII Check for Slash
               e.KeyChar == 32 ||                           //ASCII Check for Space
               e.KeyChar == 58 ||                           //ASCII Check for Colon
               e.KeyChar == 8  ||                           //ASCII Check for Backspace
               e.KeyChar == 65 ||                           //ASCII Check for 'A'
               e.KeyChar == 77 ||                           //ASCII Check for 'M'
               e.KeyChar == 80)                             //ASCII Check for 'P'
            {
                //Allow keypress
                e.Handled = false;
            }
            else if (e.KeyChar == 97 ||                     //ASCII Check for 'a'
                     e.KeyChar == 109 ||                    //ASCII Check for 'm'
                     e.KeyChar == 112)                      //ASCII Check for 'p'
            {
                //Convert these lowercase letters into their uppercase format
                e.Handled = true;
                tbxHireDate.Text += e.KeyChar.ToString().ToUpper();

                //Adjust cursor position
                tbxHireDate.Select(tbxHireDate.Text.Length, 0);
            }
            else
            {
                //Deny the keystroke
                e.Handled = true;
            }
        }

        private void tbxIsAdmin_KeyPress(object sender, KeyPressEventArgs e)
        {
            //Only allow letters and backspace
            if (e.KeyChar >= 65 && e.KeyChar <= 90 ||       //ASCII Check for Capital Letters
               e.KeyChar >= 97 && e.KeyChar <= 122 ||       //ASCII Check for Lowercase Letters
               e.KeyChar == 8)                              //ASCII Check for Backspace
            {
                //Accept the keystroke
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void tbxIsActive_KeyPress(object sender, KeyPressEventArgs e)
        {
            //Only allow letters and backspace
            if (e.KeyChar >= 65 && e.KeyChar <= 90 ||       //ASCII Check for Capital Letters
               e.KeyChar >= 97 && e.KeyChar <= 122 ||       //ASCII Check for Lowercase Letters
               e.KeyChar == 8)                              //ASCII Check for Backspace
            {
                //Accept the keystroke
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        public bool DataIsValid(string username, string password, string firstName, 
                         string lastName, string hireDate, string isAdmin, string isActive)
        {
            //Check if any string values are empty
            if (username == "" || password == "" || firstName == "" ||
                lastName == "" || hireDate == "" || isAdmin == "" || isActive == "")
            {
                MessageBox.Show("Please make sure all fields are filled in.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            //Check if the admin or active textboxes have 'true' or 'false', return false if not
            if(isAdmin != "True" && isAdmin != "False" ||
               isActive != "True" && isActive != "False")
            {
                MessageBox.Show("'Is Admin' and 'Is Active' must be either 'True' or 'False'.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            //Check if the password meets the system criteria
            bool hasNumber = false;
            int symbolCounter = 0;

            if (password.Length < 8)
                return false;

            //for loop to check character requirements
            for (int i = 0; i < password.Length; i++)
            {
                //Check the current char for a number
                if (Char.IsDigit(tbxPassword.Text[i]))
                    hasNumber = true;

                //Check the current char for a symbol
                if(!Char.IsLetter(tbxPassword.Text[i]) &&
                   !Char.IsDigit(tbxPassword.Text[i]))
                {
                    symbolCounter++;
                }
            }

            //If password criteria is met, return true
            if (hasNumber && symbolCounter >= 2)
                return true;
            else
            {
                MessageBox.Show("Password Criteria not met. Please ensure: \n- Password is at least 8 characters long. \n- Password has at least 1 number. \n- Password has at least 2 symbols.",
                                "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        private void lblDate_Click(object sender, EventArgs e)
        {
            
        }
    }
}
