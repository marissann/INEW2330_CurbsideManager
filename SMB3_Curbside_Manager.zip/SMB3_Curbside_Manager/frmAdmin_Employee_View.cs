﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SMB3_Curbside_Manager
{
    public partial class frmAdmin_Employee_View : Form
    {
        public frmAdmin_Employee_View()
        {
            InitializeComponent();
        }

        //Set up employee CurrencyManager
        CurrencyManager employeeManager;

        //Future variables for state and bookmark
        string myState = "";
        int myBookmark = 0;

        private void frmAdmin_Employee_View_Load(object sender, EventArgs e)
        {
            //Load in the Employees table from the database
            ProgOps.FetchEmployees(tbxEmployeeID, tbxUserName, tbxPassword, tbxFirstName, tbxLastName, tbxHireDate, cbxIsAdmin);

            //Fill the currency manager
            employeeManager = (CurrencyManager)this.BindingContext[ProgOps.GetEmployeeTable];
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            //Move forward one entry
            if (employeeManager.Position != employeeManager.Count - 1)
                employeeManager.Position++;
        }
        private void btnPrevious_Click(object sender, EventArgs e)
        {
            //Move back one entry
            if(employeeManager.Position != 0)
                employeeManager.Position--;
        }
        private void btnFirst_Click(object sender, EventArgs e)
        {
            //Move to the first entry
            employeeManager.Position = 0;
        }

        private void btnLast_Click(object sender, EventArgs e)
        {
            //Move to the last entry
            employeeManager.Position = employeeManager.Count - 1;
        }


    }
}
