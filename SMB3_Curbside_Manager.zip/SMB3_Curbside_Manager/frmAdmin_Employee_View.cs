﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SMB3_Curbside_Manager
{
    public partial class frmAdmin_Employee_View : Form
    {
        public frmAdmin_Employee_View()
        {
            InitializeComponent();
        }

        private void frmAdmin_Employee_View_Load(object sender, EventArgs e)
        {
            ProgOps.FetchEmployees(tbxEmployeeID, tbxUserName, tbxPassword, tbxFirstName, tbxLastName, tbxHireDate, cbxIsAdmin);
        }
    }
}
