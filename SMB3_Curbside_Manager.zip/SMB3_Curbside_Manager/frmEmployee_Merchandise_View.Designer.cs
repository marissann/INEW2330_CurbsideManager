﻿namespace SMB3_Curbside_Manager
{
    partial class frmEmployee_Merchandise_View
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbxInStock = new System.Windows.Forms.TextBox();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnEdit = new System.Windows.Forms.Button();
            this.btnAddNew = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.tbxPrice = new System.Windows.Forms.TextBox();
            this.tbxQuantity = new System.Windows.Forms.TextBox();
            this.tbxProductName = new System.Windows.Forms.TextBox();
            this.tbxCategoryID = new System.Windows.Forms.TextBox();
            this.tbxProductID = new System.Windows.Forms.TextBox();
            this.btnLast = new System.Windows.Forms.Button();
            this.btnFirst = new System.Windows.Forms.Button();
            this.btnNext = new System.Windows.Forms.Button();
            this.btnPrevious = new System.Windows.Forms.Button();
            this.lblPriceText = new System.Windows.Forms.Label();
            this.lblInStockText = new System.Windows.Forms.Label();
            this.lblProductNametxt = new System.Windows.Forms.Label();
            this.lblQuantityText = new System.Windows.Forms.Label();
            this.lblCategoryIDText = new System.Windows.Forms.Label();
            this.lblProductIDText = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // tbxInStock
            // 
            this.tbxInStock.Location = new System.Drawing.Point(263, 500);
            this.tbxInStock.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.tbxInStock.Name = "tbxInStock";
            this.tbxInStock.Size = new System.Drawing.Size(448, 29);
            this.tbxInStock.TabIndex = 108;
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(409, 683);
            this.btnClose.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(137, 42);
            this.btnClose.TabIndex = 107;
            this.btnClose.Text = "C&lose";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(578, 630);
            this.btnCancel.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(137, 42);
            this.btnCancel.TabIndex = 106;
            this.btnCancel.Text = "&Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(409, 630);
            this.btnSave.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(137, 42);
            this.btnSave.TabIndex = 105;
            this.btnSave.Text = "&Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnEdit
            // 
            this.btnEdit.Location = new System.Drawing.Point(219, 630);
            this.btnEdit.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(137, 42);
            this.btnEdit.TabIndex = 104;
            this.btnEdit.Text = "&Edit";
            this.btnEdit.UseVisualStyleBackColor = true;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // btnAddNew
            // 
            this.btnAddNew.Location = new System.Drawing.Point(48, 630);
            this.btnAddNew.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.btnAddNew.Name = "btnAddNew";
            this.btnAddNew.Size = new System.Drawing.Size(137, 42);
            this.btnAddNew.TabIndex = 103;
            this.btnAddNew.Text = "&Add New";
            this.btnAddNew.UseVisualStyleBackColor = true;
            this.btnAddNew.Click += new System.EventHandler(this.btnAddNew_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(219, 683);
            this.btnDelete.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(137, 42);
            this.btnDelete.TabIndex = 102;
            this.btnDelete.Text = "&Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // tbxPrice
            // 
            this.tbxPrice.Location = new System.Drawing.Point(260, 404);
            this.tbxPrice.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.tbxPrice.Name = "tbxPrice";
            this.tbxPrice.Size = new System.Drawing.Size(448, 29);
            this.tbxPrice.TabIndex = 101;
            // 
            // tbxQuantity
            // 
            this.tbxQuantity.Location = new System.Drawing.Point(260, 308);
            this.tbxQuantity.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.tbxQuantity.Name = "tbxQuantity";
            this.tbxQuantity.Size = new System.Drawing.Size(448, 29);
            this.tbxQuantity.TabIndex = 100;
            // 
            // tbxProductName
            // 
            this.tbxProductName.Location = new System.Drawing.Point(260, 211);
            this.tbxProductName.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.tbxProductName.Name = "tbxProductName";
            this.tbxProductName.Size = new System.Drawing.Size(448, 29);
            this.tbxProductName.TabIndex = 99;
            // 
            // tbxCategoryID
            // 
            this.tbxCategoryID.Location = new System.Drawing.Point(260, 130);
            this.tbxCategoryID.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.tbxCategoryID.Name = "tbxCategoryID";
            this.tbxCategoryID.Size = new System.Drawing.Size(448, 29);
            this.tbxCategoryID.TabIndex = 98;
            // 
            // tbxProductID
            // 
            this.tbxProductID.Location = new System.Drawing.Point(260, 44);
            this.tbxProductID.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.tbxProductID.Name = "tbxProductID";
            this.tbxProductID.Size = new System.Drawing.Size(448, 29);
            this.tbxProductID.TabIndex = 97;
            // 
            // btnLast
            // 
            this.btnLast.Location = new System.Drawing.Point(578, 575);
            this.btnLast.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.btnLast.Name = "btnLast";
            this.btnLast.Size = new System.Drawing.Size(137, 42);
            this.btnLast.TabIndex = 96;
            this.btnLast.Text = "Last";
            this.btnLast.UseVisualStyleBackColor = true;
            this.btnLast.Click += new System.EventHandler(this.btnLast_Click);
            // 
            // btnFirst
            // 
            this.btnFirst.Location = new System.Drawing.Point(409, 575);
            this.btnFirst.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.btnFirst.Name = "btnFirst";
            this.btnFirst.Size = new System.Drawing.Size(137, 42);
            this.btnFirst.TabIndex = 95;
            this.btnFirst.Text = "First";
            this.btnFirst.UseVisualStyleBackColor = true;
            this.btnFirst.Click += new System.EventHandler(this.btnFirst_Click);
            // 
            // btnNext
            // 
            this.btnNext.Location = new System.Drawing.Point(219, 575);
            this.btnNext.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(137, 42);
            this.btnNext.TabIndex = 94;
            this.btnNext.Text = "Next";
            this.btnNext.UseVisualStyleBackColor = true;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // btnPrevious
            // 
            this.btnPrevious.Location = new System.Drawing.Point(48, 575);
            this.btnPrevious.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.btnPrevious.Name = "btnPrevious";
            this.btnPrevious.Size = new System.Drawing.Size(137, 42);
            this.btnPrevious.TabIndex = 93;
            this.btnPrevious.Text = "Previous";
            this.btnPrevious.UseVisualStyleBackColor = true;
            this.btnPrevious.Click += new System.EventHandler(this.btnPrevious_Click);
            // 
            // lblPriceText
            // 
            this.lblPriceText.AutoSize = true;
            this.lblPriceText.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPriceText.Location = new System.Drawing.Point(45, 404);
            this.lblPriceText.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblPriceText.Name = "lblPriceText";
            this.lblPriceText.Size = new System.Drawing.Size(87, 29);
            this.lblPriceText.TabIndex = 92;
            this.lblPriceText.Text = "Price : ";
            this.lblPriceText.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblInStockText
            // 
            this.lblInStockText.AutoSize = true;
            this.lblInStockText.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInStockText.Location = new System.Drawing.Point(45, 500);
            this.lblInStockText.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblInStockText.Name = "lblInStockText";
            this.lblInStockText.Size = new System.Drawing.Size(116, 29);
            this.lblInStockText.TabIndex = 91;
            this.lblInStockText.Text = "In Stock : ";
            this.lblInStockText.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblProductNametxt
            // 
            this.lblProductNametxt.AutoSize = true;
            this.lblProductNametxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProductNametxt.Location = new System.Drawing.Point(45, 211);
            this.lblProductNametxt.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblProductNametxt.Name = "lblProductNametxt";
            this.lblProductNametxt.Size = new System.Drawing.Size(185, 29);
            this.lblProductNametxt.TabIndex = 90;
            this.lblProductNametxt.Text = "Product Name : ";
            this.lblProductNametxt.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblQuantityText
            // 
            this.lblQuantityText.AutoSize = true;
            this.lblQuantityText.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuantityText.Location = new System.Drawing.Point(45, 308);
            this.lblQuantityText.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblQuantityText.Name = "lblQuantityText";
            this.lblQuantityText.Size = new System.Drawing.Size(118, 29);
            this.lblQuantityText.TabIndex = 89;
            this.lblQuantityText.Text = "Quantity : ";
            this.lblQuantityText.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblCategoryIDText
            // 
            this.lblCategoryIDText.AutoSize = true;
            this.lblCategoryIDText.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCategoryIDText.Location = new System.Drawing.Point(45, 130);
            this.lblCategoryIDText.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblCategoryIDText.Name = "lblCategoryIDText";
            this.lblCategoryIDText.Size = new System.Drawing.Size(150, 29);
            this.lblCategoryIDText.TabIndex = 88;
            this.lblCategoryIDText.Text = "Catagory ID :";
            this.lblCategoryIDText.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblProductIDText
            // 
            this.lblProductIDText.AutoSize = true;
            this.lblProductIDText.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProductIDText.Location = new System.Drawing.Point(45, 50);
            this.lblProductIDText.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblProductIDText.Name = "lblProductIDText";
            this.lblProductIDText.Size = new System.Drawing.Size(137, 29);
            this.lblProductIDText.TabIndex = 87;
            this.lblProductIDText.Text = "Product ID :";
            this.lblProductIDText.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // frmEmployee_Merchandise_View
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(760, 768);
            this.ControlBox = false;
            this.Controls.Add(this.tbxInStock);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnEdit);
            this.Controls.Add(this.btnAddNew);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.tbxPrice);
            this.Controls.Add(this.tbxQuantity);
            this.Controls.Add(this.tbxProductName);
            this.Controls.Add(this.tbxCategoryID);
            this.Controls.Add(this.tbxProductID);
            this.Controls.Add(this.btnLast);
            this.Controls.Add(this.btnFirst);
            this.Controls.Add(this.btnNext);
            this.Controls.Add(this.btnPrevious);
            this.Controls.Add(this.lblPriceText);
            this.Controls.Add(this.lblInStockText);
            this.Controls.Add(this.lblProductNametxt);
            this.Controls.Add(this.lblQuantityText);
            this.Controls.Add(this.lblCategoryIDText);
            this.Controls.Add(this.lblProductIDText);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "frmEmployee_Merchandise_View";
            this.Text = "Employee: Merchandise Information";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmEmployee_Merchandise_View_FormClosing);
            this.Load += new System.EventHandler(this.frmEmployee_Merchandise_View_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbxInStock;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnEdit;
        private System.Windows.Forms.Button btnAddNew;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.TextBox tbxPrice;
        private System.Windows.Forms.TextBox tbxQuantity;
        private System.Windows.Forms.TextBox tbxProductName;
        private System.Windows.Forms.TextBox tbxCategoryID;
        private System.Windows.Forms.TextBox tbxProductID;
        private System.Windows.Forms.Button btnLast;
        private System.Windows.Forms.Button btnFirst;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.Button btnPrevious;
        private System.Windows.Forms.Label lblPriceText;
        private System.Windows.Forms.Label lblInStockText;
        private System.Windows.Forms.Label lblProductNametxt;
        private System.Windows.Forms.Label lblQuantityText;
        private System.Windows.Forms.Label lblCategoryIDText;
        private System.Windows.Forms.Label lblProductIDText;
    }
}