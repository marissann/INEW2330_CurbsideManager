﻿
namespace SMB3_Curbside_Manager
{
    partial class frmAdmin_OrderInfo_View
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnExit = new System.Windows.Forms.Button();
            this.dgvOrderInfo = new System.Windows.Forms.DataGridView();
            this.tbxEmployeeID = new System.Windows.Forms.TextBox();
            this.tbxTotalPrice = new System.Windows.Forms.TextBox();
            this.tbxOrderDate = new System.Windows.Forms.TextBox();
            this.tbxCustomerID = new System.Windows.Forms.TextBox();
            this.tbxOrderID = new System.Windows.Forms.TextBox();
            this.lblPriceText = new System.Windows.Forms.Label();
            this.lblOrderDate = new System.Windows.Forms.Label();
            this.lblQuantityText = new System.Windows.Forms.Label();
            this.lblCustomerIDText = new System.Windows.Forms.Label();
            this.lblOrderID = new System.Windows.Forms.Label();
            this.btnLeft = new System.Windows.Forms.Button();
            this.btnNext = new System.Windows.Forms.Button();
            this.btnOldest = new System.Windows.Forms.Button();
            this.btnNewest = new System.Windows.Forms.Button();
            this.btnViewandPrint = new System.Windows.Forms.Button();
            this.lblOrderDetails = new System.Windows.Forms.Label();
            this.lblLine = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvOrderInfo)).BeginInit();
            this.SuspendLayout();
            // 
            // btnExit
            // 
            this.btnExit.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(273, 442);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(101, 42);
            this.btnExit.TabIndex = 10;
            this.btnExit.Text = "E&xit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // dgvOrderInfo
            // 
            this.dgvOrderInfo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvOrderInfo.Location = new System.Drawing.Point(544, 12);
            this.dgvOrderInfo.Name = "dgvOrderInfo";
            this.dgvOrderInfo.RowHeadersWidth = 72;
            this.dgvOrderInfo.Size = new System.Drawing.Size(465, 484);
            this.dgvOrderInfo.TabIndex = 18;
            // 
            // tbxEmployeeID
            // 
            this.tbxEmployeeID.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxEmployeeID.Location = new System.Drawing.Point(149, 331);
            this.tbxEmployeeID.Name = "tbxEmployeeID";
            this.tbxEmployeeID.Size = new System.Drawing.Size(246, 27);
            this.tbxEmployeeID.TabIndex = 4;
            // 
            // tbxTotalPrice
            // 
            this.tbxTotalPrice.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxTotalPrice.Location = new System.Drawing.Point(149, 271);
            this.tbxTotalPrice.Name = "tbxTotalPrice";
            this.tbxTotalPrice.Size = new System.Drawing.Size(246, 27);
            this.tbxTotalPrice.TabIndex = 3;
            // 
            // tbxOrderDate
            // 
            this.tbxOrderDate.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxOrderDate.Location = new System.Drawing.Point(149, 211);
            this.tbxOrderDate.Name = "tbxOrderDate";
            this.tbxOrderDate.Size = new System.Drawing.Size(246, 27);
            this.tbxOrderDate.TabIndex = 2;
            // 
            // tbxCustomerID
            // 
            this.tbxCustomerID.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxCustomerID.Location = new System.Drawing.Point(149, 150);
            this.tbxCustomerID.Name = "tbxCustomerID";
            this.tbxCustomerID.Size = new System.Drawing.Size(246, 27);
            this.tbxCustomerID.TabIndex = 1;
            // 
            // tbxOrderID
            // 
            this.tbxOrderID.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxOrderID.Location = new System.Drawing.Point(149, 94);
            this.tbxOrderID.Name = "tbxOrderID";
            this.tbxOrderID.Size = new System.Drawing.Size(246, 27);
            this.tbxOrderID.TabIndex = 0;
            this.tbxOrderID.TextChanged += new System.EventHandler(this.tbxOrderID_TextChanged);
            // 
            // lblPriceText
            // 
            this.lblPriceText.AutoSize = true;
            this.lblPriceText.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPriceText.Location = new System.Drawing.Point(221, 309);
            this.lblPriceText.Name = "lblPriceText";
            this.lblPriceText.Size = new System.Drawing.Size(105, 19);
            this.lblPriceText.TabIndex = 15;
            this.lblPriceText.Text = "EmployeeID  ";
            this.lblPriceText.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblOrderDate
            // 
            this.lblOrderDate.AutoSize = true;
            this.lblOrderDate.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOrderDate.Location = new System.Drawing.Point(221, 189);
            this.lblOrderDate.Name = "lblOrderDate";
            this.lblOrderDate.Size = new System.Drawing.Size(87, 19);
            this.lblOrderDate.TabIndex = 13;
            this.lblOrderDate.Text = "Order Date";
            this.lblOrderDate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblQuantityText
            // 
            this.lblQuantityText.AutoSize = true;
            this.lblQuantityText.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuantityText.Location = new System.Drawing.Point(226, 245);
            this.lblQuantityText.Name = "lblQuantityText";
            this.lblQuantityText.Size = new System.Drawing.Size(89, 19);
            this.lblQuantityText.TabIndex = 14;
            this.lblQuantityText.Text = "Total Price ";
            this.lblQuantityText.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblCustomerIDText
            // 
            this.lblCustomerIDText.AutoSize = true;
            this.lblCustomerIDText.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCustomerIDText.Location = new System.Drawing.Point(221, 128);
            this.lblCustomerIDText.Name = "lblCustomerIDText";
            this.lblCustomerIDText.Size = new System.Drawing.Size(94, 19);
            this.lblCustomerIDText.TabIndex = 12;
            this.lblCustomerIDText.Text = "CustomerID";
            this.lblCustomerIDText.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblOrderID
            // 
            this.lblOrderID.AutoSize = true;
            this.lblOrderID.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOrderID.Location = new System.Drawing.Point(236, 72);
            this.lblOrderID.Name = "lblOrderID";
            this.lblOrderID.Size = new System.Drawing.Size(67, 19);
            this.lblOrderID.TabIndex = 11;
            this.lblOrderID.Text = "OrderID";
            this.lblOrderID.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnLeft
            // 
            this.btnLeft.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLeft.Location = new System.Drawing.Point(273, 394);
            this.btnLeft.Name = "btnLeft";
            this.btnLeft.Size = new System.Drawing.Size(101, 42);
            this.btnLeft.TabIndex = 7;
            this.btnLeft.Text = "Previous";
            this.btnLeft.UseVisualStyleBackColor = true;
            this.btnLeft.Click += new System.EventHandler(this.btnLeft_Click);
            // 
            // btnNext
            // 
            this.btnNext.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNext.Location = new System.Drawing.Point(166, 394);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(101, 42);
            this.btnNext.TabIndex = 6;
            this.btnNext.Text = "Next";
            this.btnNext.UseVisualStyleBackColor = true;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // btnOldest
            // 
            this.btnOldest.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOldest.Location = new System.Drawing.Point(59, 394);
            this.btnOldest.Name = "btnOldest";
            this.btnOldest.Size = new System.Drawing.Size(101, 42);
            this.btnOldest.TabIndex = 5;
            this.btnOldest.Text = "Oldest";
            this.btnOldest.UseVisualStyleBackColor = true;
            this.btnOldest.Click += new System.EventHandler(this.btnOldest_Click);
            // 
            // btnNewest
            // 
            this.btnNewest.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNewest.Location = new System.Drawing.Point(380, 394);
            this.btnNewest.Name = "btnNewest";
            this.btnNewest.Size = new System.Drawing.Size(101, 42);
            this.btnNewest.TabIndex = 8;
            this.btnNewest.Text = "Newest";
            this.btnNewest.UseVisualStyleBackColor = true;
            this.btnNewest.Click += new System.EventHandler(this.btnNewest_Click);
            // 
            // btnViewandPrint
            // 
            this.btnViewandPrint.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnViewandPrint.Location = new System.Drawing.Point(166, 442);
            this.btnViewandPrint.Name = "btnViewandPrint";
            this.btnViewandPrint.Size = new System.Drawing.Size(101, 42);
            this.btnViewandPrint.TabIndex = 9;
            this.btnViewandPrint.Text = "View/Print";
            this.btnViewandPrint.UseVisualStyleBackColor = true;
            this.btnViewandPrint.Click += new System.EventHandler(this.btnViewandPrint_Click);
            // 
            // lblOrderDetails
            // 
            this.lblOrderDetails.AutoSize = true;
            this.lblOrderDetails.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOrderDetails.Location = new System.Drawing.Point(206, 12);
            this.lblOrderDetails.Name = "lblOrderDetails";
            this.lblOrderDetails.Size = new System.Drawing.Size(135, 25);
            this.lblOrderDetails.TabIndex = 17;
            this.lblOrderDetails.Text = "Order Details";
            this.lblOrderDetails.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblLine
            // 
            this.lblLine.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblLine.Location = new System.Drawing.Point(12, 49);
            this.lblLine.Name = "lblLine";
            this.lblLine.Size = new System.Drawing.Size(519, 3);
            this.lblLine.TabIndex = 16;
            // 
            // frmAdmin_OrderInfo_View
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1021, 508);
            this.ControlBox = false;
            this.Controls.Add(this.lblLine);
            this.Controls.Add(this.lblOrderDetails);
            this.Controls.Add(this.btnViewandPrint);
            this.Controls.Add(this.btnNewest);
            this.Controls.Add(this.btnOldest);
            this.Controls.Add(this.btnNext);
            this.Controls.Add(this.btnLeft);
            this.Controls.Add(this.tbxEmployeeID);
            this.Controls.Add(this.tbxTotalPrice);
            this.Controls.Add(this.tbxOrderDate);
            this.Controls.Add(this.tbxCustomerID);
            this.Controls.Add(this.tbxOrderID);
            this.Controls.Add(this.lblPriceText);
            this.Controls.Add(this.lblOrderDate);
            this.Controls.Add(this.lblQuantityText);
            this.Controls.Add(this.lblCustomerIDText);
            this.Controls.Add(this.lblOrderID);
            this.Controls.Add(this.dgvOrderInfo);
            this.Controls.Add(this.btnExit);
            this.Name = "frmAdmin_OrderInfo_View";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Admin: Order Details";
            this.Load += new System.EventHandler(this.frmAdmin_OrderInfo_View_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvOrderInfo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.DataGridView dgvOrderInfo;
        private System.Windows.Forms.TextBox tbxEmployeeID;
        private System.Windows.Forms.TextBox tbxTotalPrice;
        private System.Windows.Forms.TextBox tbxOrderDate;
        private System.Windows.Forms.TextBox tbxCustomerID;
        private System.Windows.Forms.TextBox tbxOrderID;
        private System.Windows.Forms.Label lblPriceText;
        private System.Windows.Forms.Label lblOrderDate;
        private System.Windows.Forms.Label lblQuantityText;
        private System.Windows.Forms.Label lblCustomerIDText;
        private System.Windows.Forms.Label lblOrderID;
        private System.Windows.Forms.Button btnLeft;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.Button btnOldest;
        private System.Windows.Forms.Button btnNewest;
        private System.Windows.Forms.Button btnViewandPrint;
        private System.Windows.Forms.Label lblOrderDetails;
        private System.Windows.Forms.Label lblLine;
    }
}