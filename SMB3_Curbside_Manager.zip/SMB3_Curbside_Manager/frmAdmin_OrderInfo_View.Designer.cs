﻿
namespace SMB3_Curbside_Manager
{
    partial class frmAdmin_OrderInfo_View
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnExit = new System.Windows.Forms.Button();
            this.btnSearch = new System.Windows.Forms.Button();
            this.lblOrderIDtxt = new System.Windows.Forms.Label();
            this.tbxOrderIDD = new System.Windows.Forms.TextBox();
            this.dgvOrderInfo = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgvOrderInfo)).BeginInit();
            this.SuspendLayout();
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(172, 383);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(105, 52);
            this.btnExit.TabIndex = 13;
            this.btnExit.Text = "E&xit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(15, 383);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(126, 52);
            this.btnSearch.TabIndex = 12;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // lblOrderIDtxt
            // 
            this.lblOrderIDtxt.AutoSize = true;
            this.lblOrderIDtxt.Location = new System.Drawing.Point(30, 34);
            this.lblOrderIDtxt.Name = "lblOrderIDtxt";
            this.lblOrderIDtxt.Size = new System.Drawing.Size(53, 13);
            this.lblOrderIDtxt.TabIndex = 10;
            this.lblOrderIDtxt.Text = "Order ID :";
            // 
            // tbxOrderIDD
            // 
            this.tbxOrderIDD.Location = new System.Drawing.Point(89, 31);
            this.tbxOrderIDD.Name = "tbxOrderIDD";
            this.tbxOrderIDD.Size = new System.Drawing.Size(132, 20);
            this.tbxOrderIDD.TabIndex = 7;
            // 
            // dgvOrderInfo
            // 
            this.dgvOrderInfo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvOrderInfo.Location = new System.Drawing.Point(479, 12);
            this.dgvOrderInfo.Name = "dgvOrderInfo";
            this.dgvOrderInfo.Size = new System.Drawing.Size(442, 423);
            this.dgvOrderInfo.TabIndex = 14;
            // 
            // frmAdmin_OrderInfo_View
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(948, 450);
            this.Controls.Add(this.dgvOrderInfo);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.lblOrderIDtxt);
            this.Controls.Add(this.tbxOrderIDD);
            this.Name = "frmAdmin_OrderInfo_View";
            this.Text = "frmAdmin_OrderInfo_View";
            this.Load += new System.EventHandler(this.frmAdmin_OrderInfo_View_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvOrderInfo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Label lblOrderIDtxt;
        private System.Windows.Forms.TextBox tbxOrderIDD;
        private System.Windows.Forms.DataGridView dgvOrderInfo;
    }
}