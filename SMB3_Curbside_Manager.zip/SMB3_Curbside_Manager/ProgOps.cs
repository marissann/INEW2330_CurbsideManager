﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace SMB3_Curbside_Manager
{
    class ProgOps
    {
        //Variables and Constants
        //Set up connection string
        private const string CONNECT_STRING = @"Server=cstnt.tstc.edu;" +
                                                "Database=inew2330sp21;" +
                                                "User Id=group3sp212330;" +
                                                "Password=3815294;";
        //Build connection to the database
        private static SqlConnection _cntDatabase = new SqlConnection(CONNECT_STRING);
        //Functions
        public static void OpenDatabase()
        {
            try
            {
                //try to open the database
                _cntDatabase.Open();

                //Tell the user it worked
                MessageBox.Show("Connection to Database Opened Successfully!", "Connection Status",
                                MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch(Exception e)  //Note: May change to SqlException down the road
            {
                MessageBox.Show(e.Message);
            }
        }
        public static void CloseDatabase()//Attemp to Close The Database
        {
            try
            {
                _cntDatabase.Close();
                MessageBox.Show("Connection to Database Closed Successfully!" , "Connection Status" ,
                MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception e) //Note: May change to SqlException down the road
            {
                MessageBox.Show(e.Message);
            }
        }
    }
}
