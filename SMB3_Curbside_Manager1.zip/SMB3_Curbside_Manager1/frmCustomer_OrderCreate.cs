﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SMB3_Curbside_Manager
{
    public partial class frmCustomer_OrderCreate : Form
    {
        public frmCustomer_OrderCreate()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmCustomer_OrderCreate_Load(object sender, EventArgs e)
        {
            ProgOps.CreateNewOrder(tbxMerchandiseID, dgvMerchandise, true);

        }

        private void btnAddToOrder_Click(object sender, EventArgs e)
        {
            int Total;
            string total;
            if (tbxMerchandiseID.Text == "")
            {
                ProgOps.CreateNewOrder(tbxMerchandiseID, dgvMerchandise, true);

            }
            else
            {
                ProgOps.CreateNewOrder(tbxMerchandiseID, dgvMerchandise, false);
                
                lbxOrder.Items.Add("Item Name : " + dgvMerchandise.CurrentRow.Cells[1].Value.ToString());
                lbxOrder.Items.Add("Price: $" + dgvMerchandise.CurrentRow.Cells[2].Value.ToString());
                total = dgvMerchandise.CurrentRow.Cells[2].Value.ToString();
                

                ProgOps.CreateNewOrder(tbxMerchandiseID, dgvMerchandise, true);
                //lbxOrder.DataSource = dgvMerchandise.CurrentRow.Cells[2].Value.ToString().Split(',').ToList();
            }




        }

        private void btnCheckOut_Click(object sender, EventArgs e)
        {
            
        }

        private void tbxMerchandiseID_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
